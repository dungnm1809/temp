﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Implement;
using APITimekeeping.Repository.Interface;
using APITimekeeping.Service;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.IdentityModel.Tokens;
using Swashbuckle.AspNetCore.Swagger;

namespace APITimekeeping
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
             .SetBasePath(env.ContentRootPath)
             .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
             .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
             .AddEnvironmentVariables();
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<Solution_30shineContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("Solution_30shineContext")));
            //add interface, implement
            services.AddSingleton<IPushNotice, PushNotice>();
            services.AddTransient<IBookHoursRepo, BookHoursRepo>();
            services.AddTransient<IFlowTimeKeepingRepo, FlowTimeKeepingRepo>();
            services.AddTransient<IWorkTimeRepo, WorkTimeRepo>();
            services.AddTransient<IStaffRepo, StaffRepo>();
            services.AddTransient<ISMEnrollTempRepo, SMEnrollTempRepo>();
            services.AddTransient<ISMEnrollTempHourRepo, SMEnrollTempHourRepo>();
            services.AddTransient<ISalaryIncomeRepo, SalaryIncomeRepo>();
            services.AddTransient<ISalaryConfigStaffRepo, SalaryConfigStaffRepo>();
            services.AddTransient<ISalaryConfigRepo, SalaryConfigRepo>();
            services.AddTransient<ISalonRepo, SalonRepo>();
            // class business handle 
            services.AddTransient<HandleService>();

            //auth service
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = Configuration["Jwt:Issuer"],
                        ValidAudience = Configuration["Jwt:Issuer"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                    };
                });
            services.AddMvc();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    TermsOfService = "None",
                });
                c.IgnoreObsoleteActions();
                c.IgnoreObsoleteProperties();
                c.CustomSchemaIds((type) => type.FullName);
                try
                {
                    var basePath = PlatformServices.Default.Application.ApplicationBasePath;
                    var xmlPath = Path.Combine(basePath, "APITimekeeping.xml");
                    c.IncludeXmlComments(xmlPath);
                }
                catch { }
            });
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder =>
                {
                    builder
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .AllowCredentials();
                });
            });
            services.AddDirectoryBrowser();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddFile("Logs/myapp-{Date}.txt");
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            // Enable use files
            app.UseFileServer();
            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseCors(builder =>
            {
                builder.AllowAnyHeader();
                builder.AllowAnyMethod();
                builder.AllowCredentials();
                builder.AllowAnyOrigin();
                //corsBuilder.WithOrigins("http://localhost:51060/"); // for a specific url.
            });
            //use auth
            app.UseAuthentication();
            app.UseMvc();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "API V2");
                c.InjectStylesheet("/swagger/ui/custome.css");
                c.InjectStylesheet("/lib/semantic-ui/dist/semantic.css");
                c.InjectJavaScript("/lib/semantic-ui/dist/semantic.js");
                c.InjectJavaScript("/swagger/authen/custome.js");
                c.InjectJavaScript("/swagger/authen/basic-auth.js");

            });
            app.UseCors("CorsPolicy");
            app.UseAuthentication();
        }
    }
}
