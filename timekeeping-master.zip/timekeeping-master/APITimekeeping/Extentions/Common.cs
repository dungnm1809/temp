﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace APITimekeeping.Extentions
{
    public class Common
    {
        public static string GenBillCode(int salonId, string prefix, DateTime OrderDate)
        {
            return prefix + String.Format("{0:ddMMyy}", OrderDate) + salonId;
        }
    }
}
