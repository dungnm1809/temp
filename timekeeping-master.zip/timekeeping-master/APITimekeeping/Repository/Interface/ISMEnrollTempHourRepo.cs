﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using APITimekeeping.Models.Solution_30Shine;
namespace APITimekeeping.Repository.Interface
{
    public interface ISMEnrollTempHourRepo
    {
        void Add(SmEnrollTempHour obj);
        void Update(SmEnrollTempHour obj);
        void UpdateRange(IEnumerable<SmEnrollTempHour> obj);
        Task<List<SmEnrollTempHour>> GetList(Expression<Func<SmEnrollTempHour, bool>> expression);
        Task SaveChangeAsync();

    }
}
