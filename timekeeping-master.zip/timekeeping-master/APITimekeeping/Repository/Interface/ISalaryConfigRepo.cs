﻿using APITimekeeping.Models.Solution_30Shine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Interface
{
    public interface ISalaryConfigRepo
    {
        Task<SalaryConfig> Get(Expression<Func<SalaryConfig, bool>> expression);
    }
}
