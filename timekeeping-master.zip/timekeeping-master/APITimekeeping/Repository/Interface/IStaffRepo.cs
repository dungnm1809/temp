﻿using APITimekeeping.Models.Solution_30Shine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

using static APITimekeeping.Models.CustomeModel.OutPutModel;


namespace APITimekeeping.Repository.Interface
{
    public interface IStaffRepo
    {
        Task<List<Staff>> GetList(Expression<Func<Staff, bool>> expression);
        Task<List<Output_Staff>> GetListStaffNotTimekeeping(DateTime workDate,int salonId,int departmentId, List<int> listStaffId);
        Task<Staff> GetById(int staffId);
        Task<Staff> Get(Expression<Func<Staff, bool>> expression);
        void Add(Staff obj);
        void Update(Staff obj);
        Task SaveChangeAsync();

    }
}
