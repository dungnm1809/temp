﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using APITimekeeping.Models.CustomeModel;
using APITimekeeping.Models.Solution_30Shine;
using static APITimekeeping.Models.CustomeModel.OutPutModel;

namespace APITimekeeping.Repository.Interface
{
    public interface IFlowTimeKeepingRepo
    {
        Task<FlowTimeKeeping> GetById(int staffId);
        Task<FlowTimeKeeping> Get(Expression<Func<FlowTimeKeeping, bool>> expression);
        Task<List<FlowTimeKeeping>> GetList(Expression<Func<FlowTimeKeeping, bool>> expression);
        Task<OutputWorkTime> GetListFlowTimekeeping(DateTime workDate, int salonId, int departmentId);
        Task<int> GetTotalKeeping(DateTime fromDate, DateTime toDate, int staffId);
        void Add(FlowTimeKeeping obj);
        void Update(FlowTimeKeeping timeKeeping);
        void UpdateRange(List<FlowTimeKeeping> list);
        Task SaveChangeAsync();
    }
}
