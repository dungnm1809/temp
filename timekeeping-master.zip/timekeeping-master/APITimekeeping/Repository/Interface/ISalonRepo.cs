﻿using APITimekeeping.Models.Solution_30Shine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static APITimekeeping.Models.CustomeModel.OutPutModel;

namespace APITimekeeping.Repository.Interface
{
    public interface ISalonRepo
    {
        Task<TblSalon> GetById(int id);
        Task<List<Output_Salon>> GetListSalon(int staffId);
    }
}
