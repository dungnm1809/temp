﻿using APITimekeeping.Models.Solution_30Shine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Interface
{
    public interface ISalaryIncomeRepo
    {
        Task<SalaryIncome> GetById(int id);
        Task<SalaryIncome> Get(Expression<Func<SalaryIncome, bool>> expression);
        Task<List<SalaryIncome>> GetList(Expression<Func<SalaryIncome, bool>> expression);
        Task<int> CountSalaryIncome(DateTime fromDate, DateTime toDate, int staffId);
        Task<SalaryIncome> SalaryAndTimeKeepingDes(DateTime fromDate, DateTime toDate, int staffId);
        Task<(SalaryIncome, FlowTimeKeeping)> SalaryAndTimeKeepingDes456(DateTime fromDate, DateTime toDate,
            int staffId, double fixedSalary);
        Task<(SalaryIncome, FlowTimeKeeping)> SalaryAndTimeKeepingAsc(DateTime fromDate, DateTime toDate, int staffId);
        Task<(SalaryIncome, FlowTimeKeeping)> SalaryAndTimeKeepingAsc456(DateTime fromDate, DateTime toDate,
            int staffId, double fixedSalary);
        void Add(SalaryIncome obj);
        void Update(SalaryIncome obj);
        Task SaveChangeAsync();
    }
}
