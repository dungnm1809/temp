﻿using APITimekeeping.Models.Solution_30Shine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Interface
{
    public interface IWorkTimeRepo
    {
        Task<WorkTime> GetById(int id);
        Task<List<WorkTime>> GetList(Expression<Func<WorkTime, bool>> expression);
        Task<WorkTime> Get(Expression<Func<WorkTime, bool>> expression);
    }
}
