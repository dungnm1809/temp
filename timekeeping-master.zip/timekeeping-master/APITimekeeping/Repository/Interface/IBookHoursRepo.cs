﻿using APITimekeeping.Models.Solution_30Shine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Interface
{
    public interface IBookHoursRepo
    {
        Task<List<BookHour>> GetList(Expression<Func<BookHour, bool>> expression);
        Task<string> GetLstHourId(int workTimeId, int salonId);
    }
}
