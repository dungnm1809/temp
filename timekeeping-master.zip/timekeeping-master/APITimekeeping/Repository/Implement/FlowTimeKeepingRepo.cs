﻿using APITimekeeping.Extentions;
using APITimekeeping.Models.CustomeModel;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using APITimekeeping.Utils;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using static APITimekeeping.Models.CustomeModel.OutPutModel;

namespace APITimekeeping.Repository.Implement
{
    public class FlowTimeKeepingRepo : IFlowTimeKeepingRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<FlowTimeKeeping> dbSet;
        //constructor
        public FlowTimeKeepingRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<FlowTimeKeeping>();
        }

        /// <summary>
        /// Get time keeping
        /// </summary>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public async Task<FlowTimeKeeping> Get(Expression<Func<FlowTimeKeeping, bool>> expression)
        {
            try
            {
                return await dbSet.FirstOrDefaultAsync(expression);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<FlowTimeKeeping>> GetList(Expression<Func<FlowTimeKeeping, bool>> expression)
        {
            try
            {
                var data = await dbSet.Where(expression).ToListAsync();
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public async Task<FlowTimeKeeping> GetById(int staffId)
        {
            try
            {
                return await dbSet.FirstOrDefaultAsync(w => w.StaffId == staffId && w.IsDelete == 0 && w.IsEnroll == true && w.WorkDate == DateTime.Now.Date);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get total timekeeping
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public async Task<int> GetTotalKeeping(DateTime fromDate, DateTime toDate, int staffId)
        {
            try
            {
                var data = await (
                                    from a in dbContext.FlowTimeKeeping.AsNoTracking()
                                    join b in dbContext.TblSalon.AsNoTracking() on a.SalonId equals b.Id
                                    where
                                        a.WorkDate >= fromDate && a.WorkDate <= toDate
                                        && a.StaffId == staffId && a.IsDelete == 0
                                        && a.IsEnroll == true && b.IsSalonHoiQuan == false
                                    select a.Id
                                 ).CountAsync();
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list flow timekeeping
        /// </summary>
        /// <param name="workDate"></param>
        /// <param name="salonId"></param>
        /// <param name="departmentId"></param>
        /// <returns></returns>
        public async Task<OutputWorkTime> GetListFlowTimekeeping(DateTime workDate, int salonId, int departmentId)
        {
            try
            {
                var list = new OutputWorkTime();
                var data = (from a in dbContext.FlowTimeKeeping.AsNoTracking()
                            join b in dbContext.Staff.AsNoTracking() on a.StaffId equals b.Id
                            join c in dbContext.WorkTime.AsNoTracking() on a.WorkTimeId equals c.Id
                            join d in dbContext.TblSalon.AsNoTracking() on b.SalonId equals d.Id
                            join e in dbContext.StaffType.AsNoTracking() on b.Type equals e.Id
                            where a.WorkDate == workDate
                                    && a.SalonId == salonId
                                    && ((b.Type == departmentId) || (departmentId == 0))
                                    && a.IsEnroll == true
                                    && a.IsDelete == 0
                                    && b.IsDelete == 0
                            select new OutPutFlowTimeKeeping
                            {
                                WorkDate = string.Format("{0:dd/MM/yyyy}", a.WorkDate),
                                StaffId = b.Id,
                                StaffName = b.Fullname,
                                StaffStatus =
                                    (
                                        b.Active == 0 ? "(Đã nghỉ)" :
                                        b.Active == 1 ? "" :
                                        b.Active == 2 ? "(Nghỉ tạm thời)" : ""
                                    ),
                                SalonId = b.SalonId ?? 0,
                                SalonTimekeepingId = a.SalonId,
                                SalonName = d.Name,
                                ShortName = d.ShortName,
                                //ShortName = d.ShortName,
                                DepartmentId = b.Type,
                                DepartmentName = e.Name,
                                Parttime = a.WorkHour,
                                WorkHour = a.WorkHour,
                                WorkTimeId = a.WorkTimeId,
                                Color = c.Color,
                                HourIds = a.HourIds
                            }).ToList();
                if (data.Count > 0)
                {
                    var listStaffId = data.Select(s => s.StaffId);
                    var timekeeping = (
                                         from t in dbContext.FlowTimeKeeping.AsNoTracking()
                                         join s in dbContext.TblSalon.AsNoTracking() on t.SalonId equals s.Id
                                         join staff in dbContext.Staff.AsNoTracking() on t.StaffId equals staff.Id
                                         where
                                         t.IsEnroll == true
                                         && t.WorkDate == workDate
                                         && t.IsDelete == 0
                                         && listStaffId.Contains(t.StaffId)
                                         && s.IsDelete == 0
                                         && s.Publish == true
                                         && staff.IsDelete == 0
                                         select new
                                         {
                                             StaffId = t.StaffId,
                                             SalonId = t.SalonId,
                                             SalonName = s.ShortName,
                                             Partime = t.WorkHour
                                         }).ToList();
                    foreach (var item in data)
                    {
                        var record = timekeeping.FirstOrDefault(a => a.StaffId == item.StaffId);
                        if (record != null)
                        {
                            item.SalonIdWorking = record.SalonId;
                            if (salonId != record.SalonId)
                            {
                                item.NoteStatusSalonCurrent = $@"(Salon đang làm việc: {record.SalonName ?? ""})";
                                item.Parttime = Convert.ToInt32(record.Partime);
                            }
                        }
                        if (item.SalonId != salonId)
                        {
                            item.NoteStatus = $@"(Salon hiện tại: {item.ShortName ?? ""})";
                        }
                    }
                }

                list = new OutputWorkTime
                {
                    Ca1 = data.Where(w => w.WorkTimeId == AppConstants.WorkTimeIdCa1).OrderBy(w => w.StaffId).ToList(),
                    Ca2 = data.Where(w => w.WorkTimeId == AppConstants.WorkTimeIdCa2).OrderBy(w => w.StaffId).ToList(),
                    Ca3 = data.Where(w => w.WorkTimeId == AppConstants.WorkTimeIdCa3).OrderBy(w => w.StaffId).ToList(),
                    Ca11 = data.Where(w => w.WorkTimeId == AppConstants.WorkTimeIdCa11).OrderBy(w => w.StaffId).ToList(),
                    Ca31 = data.Where(w => w.WorkTimeId == AppConstants.WorkTimeIdCa31).OrderBy(w => w.StaffId).ToList()
                };

                return list;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Add
        /// </summary>
        /// <param name="obj"></param>
        public void Add(FlowTimeKeeping obj)
        {
            try
            {
                dbSet.Add(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="timeKeeping"></param>
        public void Update(FlowTimeKeeping timeKeeping)
        {
            try
            {
                dbSet.Update(timeKeeping);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        /// <summary>
        /// Update range
        /// </summary>
        /// <param name="list"></param>
        public void UpdateRange(List<FlowTimeKeeping> list)
        {
            try
            {
                dbSet.UpdateRange(list);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// save change
        /// </summary>
        /// <returns></returns>
        public async Task SaveChangeAsync()
        {
            try
            {
                await dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}

