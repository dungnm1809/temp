﻿using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Implement
{
    public class SalaryConfigStaffRepo: ISalaryConfigStaffRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<SalaryConfigStaff> dbSet;
        //constructor
        public SalaryConfigStaffRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<SalaryConfigStaff>();
        }

        /// <summary>
        /// Get 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<SalaryConfigStaff> Get(Expression<Func<SalaryConfigStaff, bool>> expression)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(expression);
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get by staff id
        /// </summary>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public async Task<SalaryConfigStaff> GetByStaffId(int staffId)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(r => r.StaffId == staffId && r.IsDeleted == false);
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
