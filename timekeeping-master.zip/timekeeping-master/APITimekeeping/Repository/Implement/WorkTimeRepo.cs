﻿using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Implement
{
    public class WorkTimeRepo : IWorkTimeRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<WorkTime> dbSet;

        //contrucstor
        public WorkTimeRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<WorkTime>();
        }

        /// <summary>
        /// Get
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<WorkTime> Get(Expression<Func<WorkTime, bool>> expression)
        {
            try
            {
                return await dbSet.FirstOrDefaultAsync(expression);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<WorkTime> GetById(int id)
        {
            try
            {
                return await dbSet.FirstOrDefaultAsync(w => w.Id == id && w.Publish == true && w.IsDelete == 0);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<WorkTime>> GetList(Expression<Func<WorkTime, bool>> expression)
        {
            try
            {
                return await dbSet.Where(expression).ToListAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
