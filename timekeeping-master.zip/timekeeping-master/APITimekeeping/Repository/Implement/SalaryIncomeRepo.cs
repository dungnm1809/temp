﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace APITimekeeping.Repository.Implement
{
    public class SalaryIncomeRepo : ISalaryIncomeRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<SalaryIncome> dbSet;
        //constructor
        public SalaryIncomeRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<SalaryIncome>();
        }

        /// <summary>
        /// Get by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<SalaryIncome> GetById(int id)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(r => r.Id == id && r.IsDeleted == false);
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<SalaryIncome> Get(Expression<Func<SalaryIncome, bool>> expression)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(expression);
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<SalaryIncome>> GetList(Expression<Func<SalaryIncome, bool>> expression)
        {
            try
            {
                var data = await dbSet.Where(expression).ToListAsync();
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Count record in table SalaryIncome
        /// </summary>
        /// <returns></returns>
        public async Task<int> CountSalaryIncome(DateTime fromDate, DateTime toDate, int staffId)
        {
            try
            {
                var data = await (from a in dbContext.SalaryIncome.AsNoTracking()
                                  join b in dbContext.FlowTimeKeeping.AsNoTracking() on a.StaffId equals b.StaffId
                                  join c in dbContext.TblSalon.AsNoTracking() on a.SalonId equals c.Id
                                  where a.IsDeleted == false
                                        && c.IsSalonHoiQuan == false
                                        && b.IsDelete == 0
                                        && b.IsEnroll == true
                                        && b.WorkDate == a.WorkDate
                                        && a.WorkDate >= fromDate && a.WorkDate < toDate
                                        && b.StaffId == staffId
                                        && a.StaffId == staffId
                                        && a.FixedSalary > 0
                                  select a.Id)
                                  .CountAsync();
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get record 
        /// </summary>
        /// <returns></returns>
        public async Task<SalaryIncome> SalaryAndTimeKeepingDes(DateTime fromDate, DateTime toDate, int staffId)
        {
            try
            {
                var data = await (from a in dbContext.SalaryIncome.AsNoTracking()
                                  join b in dbContext.FlowTimeKeeping.AsNoTracking() on a.StaffId equals b.StaffId
                                  where b.IsEnroll == true
                                        && b.IsDelete == 0
                                        && a.IsDeleted == false
                                        && b.WorkDate == a.WorkDate
                                        && b.WorkDate >= fromDate && b.WorkDate <= toDate
                                        && b.StaffId == staffId
                                        && a.FixedSalary > 0
                                  select a)
                                  .OrderByDescending(r => r.WorkDate)
                                  .FirstOrDefaultAsync();
                return data;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<(SalaryIncome, FlowTimeKeeping)> SalaryAndTimeKeepingDes456(DateTime fromDate, DateTime toDate, int staffId, double fixedSalary)
        {
            try
            {
                var data = await (from a in dbContext.SalaryIncome
                                  join b in dbContext.FlowTimeKeeping on a.StaffId equals b.StaffId
                                  where b.IsEnroll == true
                                        && b.IsDelete == 0
                                        && a.IsDeleted == false
                                        && b.WorkDate == a.WorkDate
                                        && b.WorkDate >= fromDate && b.WorkDate <= toDate
                                        && b.StaffId == staffId
                                        && a.FixedSalary == fixedSalary
                                  select new
                                  {
                                      salaryIncome = a,
                                      flowtimeKeeping = b
                                  })
                                  .OrderBy(r => r.flowtimeKeeping.WorkDate)
                                  .FirstOrDefaultAsync();

                return (data == null ? null : data.salaryIncome, data == null ? null : data.flowtimeKeeping);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<(SalaryIncome, FlowTimeKeeping)> SalaryAndTimeKeepingAsc(DateTime fromDate, DateTime toDate, int staffId)
        {
            try
            {
                var data = await (from a in dbContext.SalaryIncome
                                  join b in dbContext.FlowTimeKeeping on a.StaffId equals b.StaffId
                                  where b.IsEnroll == true
                                        && b.IsDelete == 0
                                        && a.IsDeleted == false
                                        && b.WorkDate == a.WorkDate
                                        && b.WorkDate >= fromDate && b.WorkDate <= toDate
                                        && b.StaffId == staffId
                                        && a.FixedSalary == 0
                                  select new
                                  {
                                      salaryIncome = a,
                                      flowtimeKeeping = b
                                  })
                                  .OrderBy(r => r.flowtimeKeeping.WorkDate)
                                  .FirstOrDefaultAsync();

                return (data == null ? null : data.salaryIncome, data == null ? null : data.flowtimeKeeping);

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<(SalaryIncome, FlowTimeKeeping)> SalaryAndTimeKeepingAsc456(DateTime fromDate, DateTime toDate, int staffId, double fixedSalary)
        {
            try
            {
                var data = await (from a in dbContext.SalaryIncome
                                  join b in dbContext.FlowTimeKeeping on a.StaffId equals b.StaffId
                                  where b.IsEnroll == true
                                        && b.IsDelete == 0
                                        && a.IsDeleted == false
                                        && b.WorkDate == a.WorkDate
                                        && b.WorkDate >= fromDate && b.WorkDate <= toDate
                                        && b.StaffId == staffId
                                        && a.FixedSalary > fixedSalary
                                  select new
                                  {
                                      salaryIncome = a,
                                      flowtimeKeeping = b
                                  })
                                  .OrderBy(r => r.flowtimeKeeping.WorkDate)
                                  .FirstOrDefaultAsync();

                return (data == null ? null : data.salaryIncome, data == null ? null : data.flowtimeKeeping);

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Add
        /// </summary>
        /// <param name="obj"></param>
        public void Add(SalaryIncome obj)
        {
            try
            {
                dbSet.Add(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj"></param>
        public void Update(SalaryIncome obj)
        {
            try
            {
                dbSet.Update(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Save change
        /// </summary>
        /// <returns></returns>
        public async Task SaveChangeAsync()
        {
            try
            {
                await dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
