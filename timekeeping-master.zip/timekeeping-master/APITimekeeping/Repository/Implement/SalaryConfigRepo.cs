﻿using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Implement
{
    public class SalaryConfigRepo: ISalaryConfigRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<SalaryConfig> dbSet;
        //constructor
        public SalaryConfigRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<SalaryConfig>();
        }

        /// <summary>
        /// Get 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<SalaryConfig> Get(Expression<Func<SalaryConfig, bool>> expression)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(expression);
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
