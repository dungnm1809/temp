﻿using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Implement
{
    public class BookHoursRepo : IBookHoursRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<BookHour> dbSet;
        //constructor
        public BookHoursRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<BookHour>();
        }

        /// <summary>
        /// Get list by Salon
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<BookHour>> GetList(Expression<Func<BookHour, bool>> expression)
        {
            try
            {
                var data = await dbSet.Where(expression).ToListAsync();
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list hourId
        /// </summary>
        /// <param name="workTimeId"></param>
        /// <param name="salonId"></param>
        /// <returns></returns>
        public async Task<string> GetLstHourId(int workTimeId, int salonId)
        {
            try
            {
                var str = "";
                if (workTimeId > 0)
                {
                    var worktime = await dbContext.WorkTime.FirstOrDefaultAsync(r => r.Id == workTimeId);
                    if (worktime != null)
                    {
                        var bookHour = await dbContext.BookHour.Where(r =>
                            r.HourFrame >= worktime.StrartTime &&
                            r.HourFrame <= worktime.EnadTime &&
                            r.HourFrame != worktime.Lunchhour &&
                            r.HourFrame != worktime.Lunchhour2 &&
                            r.SalonId == salonId)
                            .Select(r => r.Id).ToArrayAsync();
                        str = string.Join(",", bookHour);
                    }
                }

                return str;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
