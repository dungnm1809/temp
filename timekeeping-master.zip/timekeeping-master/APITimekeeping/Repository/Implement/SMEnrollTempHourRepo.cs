﻿using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Implement
{
    public class SMEnrollTempHourRepo : ISMEnrollTempHourRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<SmEnrollTempHour> dbSet;
        //constructor
        public SMEnrollTempHourRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<SmEnrollTempHour>();
        }

        /// <summary>
        /// add range 
        /// </summary>
        /// <param name="obj"></param>
        public void Add(SmEnrollTempHour obj)
        {
            try
            {
                dbContext.SmEnrollTempHour.Add(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Update range
        /// </summary>
        /// <param name="obj"></param>
        public void Update(SmEnrollTempHour obj)
        {
            try
            {
                dbContext.SmEnrollTempHour.Update(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<SmEnrollTempHour>> GetList(Expression<Func<SmEnrollTempHour, bool>> expression)
        {
            try
            {
                return await dbSet.Where(expression).ToListAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Save change async
        /// </summary>
        /// <returns></returns>
        public async Task SaveChangeAsync()
        {
            try
            {
                await dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// UpdateRange
        /// </summary>
        /// <param name="obj"></param>
        public void UpdateRange(IEnumerable<SmEnrollTempHour> obj)
        {
            try
            {
                dbSet.UpdateRange(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
