﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using static APITimekeeping.Models.CustomeModel.OutPutModel;

namespace APITimekeeping.Repository.Implement
{
    public class SalonRepo: ISalonRepo
    {
        private Solution_30shineContext dbContext;
        private DbSet<TblSalon> dbSet;

        public SalonRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<TblSalon>();
        }

        /// <summary>
        /// Get by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<TblSalon> GetById(int id)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(r => r.Id == id);
                return data;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw e;
            }
        }

        /// <summary>
        /// Get salon IvInventory
        /// </summary>
        /// <returns></returns>
        public async Task<List<Output_Salon>> GetListSalon(int staffId)
        {
            try
            {
                var list = new List<Output_Salon>();
                var dataStaff = await (from b in dbContext.Staff.AsNoTracking()
                                       where b.Id == staffId
                                       && b.Active == 1
                                       && b.IsDelete == 0
                                       select new
                                       {
                                           staffId = b.Id,
                                           salonId = b.SalonId ?? 0
                                       }).FirstOrDefaultAsync();

                var checkExistASM = (from c in dbContext.PermissionSalonArea
                                     where Convert.ToInt32(dataStaff.staffId) == c.StaffId
                                     select c.SalonId).ToList();
                // get list Salon
                var listSalon = dbContext.TblSalon.AsNoTracking().Where(a => a.IsDelete == 0 && a.Publish == true).ToList();

                if (checkExistASM.Count <= 0 && dataStaff.salonId == 0)
                {
                    list = (from b in listSalon
                            where b.IsDelete == 0
                                && b.Publish == true
                                && b.IsSalonHoiQuan == false
                            select new Output_Salon
                            {
                                Id = b.Id,
                                SalonName = b.Name
                            }).ToList();
                }
                else if (checkExistASM.Count > 0 && dataStaff.salonId == 0)
                {
                    list = (from b in listSalon
                            where b.IsDelete == 0
                                && b.Publish == true
                                && b.IsSalonHoiQuan == false
                                && checkExistASM.Contains(b.Id)
                            select new Output_Salon
                            {
                                Id = b.Id,
                                SalonName = b.Name
                            }).ToList();
                }
                else
                {
                    list = (from b in listSalon
                            where b.IsDelete == 0
                                && b.Publish == true
                                && b.IsSalonHoiQuan == false
                                && b.Id == dataStaff.salonId
                            select new Output_Salon
                            {
                                Id = b.Id,
                                SalonName = b.Name
                            }).ToList();
                }

                return list;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
