﻿using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace APITimekeeping.Repository.Implement
{
    public class SMEnrollTempRepo : ISMEnrollTempRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<SmEnrollTemp> dbSet;
        //constructor
        public SMEnrollTempRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<SmEnrollTemp>();
        }

        /// <summary>
        /// Get 
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<SmEnrollTemp> Get(Expression<Func<SmEnrollTemp, bool>> expression)
        {
            try
            {
                return await dbSet.FirstOrDefaultAsync(expression);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// add
        /// </summary>
        /// <param name="obj"></param>
        public void Add(SmEnrollTemp obj)
        {
            try
            {
                dbSet.Add(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj"></param>
        public void Update(SmEnrollTemp obj)
        {
            try
            {
                dbSet.Update(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// save change
        /// </summary>
        /// <returns></returns>
        public async Task SaveChangeAsync()
        {
            try
            {
                await dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<SmEnrollTemp>> GetList(Expression<Func<SmEnrollTemp, bool>> expression)
        {
            try
            {
                return await dbSet.Where(expression).ToListAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Update range
        /// </summary>
        /// <param name="obj"></param>
        public void UpdateRange(IEnumerable<SmEnrollTemp> obj)
        {
            try
            {
                dbSet.UpdateRange(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
