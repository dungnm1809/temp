﻿using APITimekeeping.Models.CustomeModel;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

using static APITimekeeping.Models.CustomeModel.OutPutModel;


namespace APITimekeeping.Repository.Implement
{
    public class StaffRepo : IStaffRepo
    {
        private readonly Solution_30shineContext dbContext;
        private readonly DbSet<Staff> dbSet;

        //constructor
        public StaffRepo(Solution_30shineContext dbContext)
        {
            this.dbContext = dbContext;
            dbSet = dbContext.Set<Staff>();
        }

        /// <summary>
        /// Get by Id
        /// </summary>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public async Task<Staff> GetById(int staffId)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(r => r.Id == staffId && r.IsDelete == 0);
                return data;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list staff not timekeeping
        /// </summary>
        /// <param name="salonId"></param>
        /// <param name="departmentId"></param>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public async Task<List<OutPutModel.Output_Staff>> GetListStaffNotTimekeeping(DateTime workDate, int salonId, int departmentId, List<int> listStaffId)
        {
            try
            {
                List<Output_Staff> data = new List<Output_Staff>();
                if (listStaffId.Count > 0)
                {
                    data = await (from a in dbContext.Staff.AsNoTracking()
                                  join b in dbContext.StaffType.AsNoTracking() on a.Type equals b.Id
                                  where a.SalonId == salonId
                                  && ((a.Type == departmentId) || (departmentId == 0))
                                  && !listStaffId.Contains(a.Id)
                                  && a.Active == 1
                                  && a.IsDelete == 0
                                  && a.RequireEnroll == true
                                  select new Output_Staff
                                  {
                                      Id = a.Id,
                                      FullName = a.Fullname,
                                      SalonId = a.SalonId ?? 0,
                                      DepartmentId = a.Type ?? 0,
                                      DepartmentName = b.Name,
                                      SalonIdWorking = a.SalonId ?? 0
                                  }).OrderBy(o => o.DepartmentId)
                                  .ToListAsync();
                }
                else
                {
                    data = await (from a in dbContext.Staff.AsNoTracking()
                                  join b in dbContext.StaffType.AsNoTracking() on a.Type equals b.Id
                                  where a.SalonId == salonId
                                  && ((a.Type == departmentId) || (departmentId == 0))
                                  && a.Active == 1
                                  && a.IsDelete == 0
                                  && a.RequireEnroll == true
                                  select new Output_Staff
                                  {
                                      Id = a.Id,
                                      FullName = a.Fullname,
                                      SalonId = a.SalonId ?? 0,
                                      DepartmentId = a.Type ?? 0,
                                      DepartmentName = b.Name,
                                      SalonIdWorking = a.SalonId ?? 0
                                  }).OrderBy(o => o.DepartmentId)
                                  .ToListAsync();
                }
                if (data.Count > 0)
                {
                    var listId = data.Select(s => s.Id);
                    var timekeeping = (
                                      from t in dbContext.FlowTimeKeeping.AsNoTracking()
                                      join s in dbContext.TblSalon.AsNoTracking() on t.SalonId equals s.Id
                                      join staff in dbContext.Staff.AsNoTracking() on t.StaffId equals staff.Id
                                      where
                                      t.IsEnroll == true
                                      && t.WorkDate == workDate
                                      && t.IsDelete == 0
                                      && listId.Contains(t.StaffId)
                                      && s.IsDelete == 0
                                      && s.Publish == true
                                      && staff.IsDelete == 0
                                      && staff.Active == 1
                                      select new
                                      {
                                          StaffId = t.StaffId,
                                          SalonId = t.SalonId,
                                          SalonName = s.ShortName,
                                          Partime = t.WorkHour
                                      }).ToList();
                    foreach (var item in data)
                    {
                        var record = timekeeping.FirstOrDefault(a => a.StaffId == item.Id);
                        if (record != null)
                        {
                            item.SalonIdWorking = record.SalonId;
                            if (salonId != record.SalonId)
                            {
                                item.NoteStatusSalonCurrent = $@"(Salon đang làm việc: {record.SalonName ?? ""})";
                            }
                        }
                    }
                }
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<Staff> Get(Expression<Func<Staff, bool>> expression)
        {
            try
            {
                var data = await dbSet.FirstOrDefaultAsync(expression);
                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public async Task<List<Staff>> GetList(Expression<Func<Staff, bool>> expression)
        {
            try
            {
                var data = await dbSet.Where(expression).ToListAsync();

                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Add
        /// </summary>
        /// <param name="obj"></param>
        public void Add(Staff obj)
        {
            try
            {
                dbSet.Add(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj"></param>
        public void Update(Staff obj)
        {
            try
            {
                dbSet.Update(obj);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Save change
        /// </summary>
        /// <returns></returns>
        public async Task SaveChangeAsync()
        {
            try
            {
                await dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
