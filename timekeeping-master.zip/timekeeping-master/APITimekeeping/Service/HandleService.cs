﻿using APITimekeeping.Extentions;
using APITimekeeping.Models.CustomeModel;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using APITimekeeping.Utils;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using static APITimekeeping.Models.CustomeModel.OutPutModel;

namespace APITimekeeping.Service
{
    public class HandleService
    {
        private ILogger<HandleService> Logger { get; }
        private readonly IPushNotice PushNotice;
        private readonly IFlowTimeKeepingRepo FlowTimeKeepingRepo;
        private readonly IBookHoursRepo BookHoursRepo;
        private readonly IWorkTimeRepo WorkTimeRepo;
        private readonly IStaffRepo StaffRepo;
        private readonly ISMEnrollTempRepo SMEnrollTempRepo;
        private readonly ISMEnrollTempHourRepo SMEnrollTempHourRepo;
        private readonly ISalaryIncomeRepo SalaryIncomeRepo;
        private readonly ISalaryConfigStaffRepo SalaryConfigStaffRepo;
        private readonly ISalaryConfigRepo SalaryConfigRepo;
        private readonly ISalonRepo SalonRepo;

        // constructor
        public HandleService(ILogger<HandleService> logger,
            IPushNotice pushNotice,
            IFlowTimeKeepingRepo flowTimeKeepingRepo,
            IBookHoursRepo bookHoursRepo,
            IWorkTimeRepo workTimeRepo,
            IStaffRepo staffRepo,
            ISMEnrollTempRepo sMEnrollTempRepo,
            ISMEnrollTempHourRepo sMEnrollTempHourRepo,
            ISalaryIncomeRepo salaryIncomeRepo,
            ISalaryConfigStaffRepo salaryConfigStaffRepo,
            ISalaryConfigRepo salaryConfigRepo,
            ISalonRepo salonRepo)
        {
            Logger = logger;
            PushNotice = pushNotice;
            FlowTimeKeepingRepo = flowTimeKeepingRepo;
            BookHoursRepo = bookHoursRepo;
            WorkTimeRepo = workTimeRepo;
            StaffRepo = staffRepo;
            SMEnrollTempRepo = sMEnrollTempRepo;
            SMEnrollTempHourRepo = sMEnrollTempHourRepo;
            SalaryIncomeRepo = salaryIncomeRepo;
            SalaryConfigStaffRepo = salaryConfigStaffRepo;
            SalaryConfigRepo = salaryConfigRepo;
            SalonRepo = salonRepo;
        }

        /// <summary>
        /// Output
        /// </summary>
        /// <param name="staffId"></param>
        /// <returns></returns>
        public async Task<MainFlowTimeKeeping> GetHourTimeKeeping(int staffId, string workDate)

        {
            try
            {
                var data = new OutPutModel.MainFlowTimeKeeping();
                var list = new List<OutPutModel.FlowTimeKeepingHour>();
                var objTimekeeping = new FlowTimeKeeping();
                if (string.IsNullOrEmpty(workDate))
                {
                    //lấy record timekeeping ngày hiện tại
                    objTimekeeping = await FlowTimeKeepingRepo.Get(w => w.StaffId == staffId
                                                                            && w.IsDelete == 0
                                                                            && w.IsEnroll == true
                                                                            && w.WorkDate == DateTime.Now.Date);
                }
                else
                {
                    // lấy record timekeeping theo ngày truyền vào 
                    var WorkDate = Convert.ToDateTime(workDate, DatetimeExtension.GetCultureInfo());
                    objTimekeeping = await FlowTimeKeepingRepo.Get(w => w.StaffId == staffId
                                                                           && w.IsDelete == 0
                                                                           && w.IsEnroll == true
                                                                           && w.WorkDate == WorkDate);
                }
                if (objTimekeeping != null)
                {
                    // lấy ra ca làm việc
                    var wokTime = await WorkTimeRepo.GetById(objTimekeeping.WorkTimeId ?? 0);
                    // xử lý chuỗi Hours format 1,2,3,4
                    var listHourIds = objTimekeeping.HourIds.ConvertTimeKeeping();
                    //lấy ra salonId mà nhân viên đó được chấm công
                    int SalonId = objTimekeeping.SalonId;
                    // lấy ra list hourId của ca làm việc
                    var bookHourIdDo = await BookHoursRepo.GetList(r => r.SalonId == SalonId && r.IsDelete == 0 && r.Publish == true
                                                                && r.HourFrame >= wokTime.StrartTime
                                                                && r.HourFrame <= wokTime.EnadTime);
                    //lấy ra khung giờ của salon
                    var bookHours = BookHoursRepo.GetList(r => r.IsDelete == 0 && r.Publish == true && r.SalonId == SalonId).Result.OrderBy(o => o.HourFrame);
                    // lấy tổng giờ tăng ca
                    data.TotalTime = objTimekeeping.WorkHour ?? 0;
                    //data.WorkName = wokTime.WName + $"[{wokTime.StrartTime} - {wokTime.EnadTime}]";
                    //tên ca làm việc
                    data.WorkTimeId = wokTime.Id;
                    data.WorkName = wokTime.WName == null ? "" : wokTime.WName;
                    foreach (var item in bookHours)
                    {
                        var obj = new OutPutModel.FlowTimeKeepingHour();
                        // 
                        var record = listHourIds.FirstOrDefault(w => w == item.Id);
                        // sử dụng Any để kiểm tra có tồn tại giờ chấm công hay không
                        if (bookHours.Any(w => w.Id == record))
                        {
                            //Hour khung giờ chấm công
                            obj.HourId = item.Id;
                            obj.HourFrame = item.HourFrame.ToString();
                            obj.Hour = item.Hour;
                            //Iskeeping giờ chấm công true/false
                            obj.Iskeeping = true;
                            if (bookHourIdDo.Any(w => w.Id == record))
                            {
                                //IsOverTime giờ tăng ca true/false
                                obj.IsOverTime = false;
                            }
                            else
                            {
                                obj.IsOverTime = true;
                            }
                        }
                        else
                        {
                            obj.HourId = item.Id;
                            obj.HourFrame = item.HourFrame.ToString();
                            obj.Hour = item.Hour;
                            obj.Iskeeping = false;
                            obj.IsOverTime = false;
                        }
                        //add list
                        list.Add(obj);
                    }
                }
                // list hour
                data.Hours = list;

                return data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// add Enroll
        /// </summary>
        /// <returns></returns>
        public async Task AddUpdateFlowtimekeeping(int salonId, int workTimeId, DateTime WorkDate, IEnumerable<int> listStaffId, int doUserId, string strHourId)
        {
            try
            {
                // get list departmentId
                var listStaffType = await StaffRepo.GetList(a => a.IsDelete == 0 && a.Active == 1 && listStaffId.Contains(a.Id));
                // check Stylist xem có chuyển salon hay không
                foreach (var v in listStaffId)
                {
                    var checkData = await FlowTimeKeepingRepo.Get(a => a.WorkDate == WorkDate
                                                                 && a.StaffId == v
                                                                 && a.SalonId != salonId
                                                                 && a.IsEnroll == true);

                    if (checkData != null)
                    {
                        checkData.IsDelete = 1;
                        checkData.IsEnroll = false;
                        checkData.WorkHour = 0;
                        FlowTimeKeepingRepo.Update(checkData);
                        await FlowTimeKeepingRepo.SaveChangeAsync();
                    }
                    //checkDataExist
                    var checkDataExist = await FlowTimeKeepingRepo.Get(a => a.WorkDate == WorkDate
                                                                 && a.StaffId == v
                                                                 && a.SalonId == salonId);
                    // get type
                    var departmentId = listStaffType.FirstOrDefault(a => a.Id == v).Type;
                    // nếu đã tồn tại record mà bị delete thì update lại
                    if (checkDataExist != null)
                    {
                        checkDataExist.IsEnroll = true;
                        checkDataExist.IsDelete = 0;
                        checkDataExist.WorkTimeId = workTimeId;
                        checkDataExist.HourIds = strHourId;
                        checkDataExist.WorkHour = 0;
                        checkDataExist.Type = departmentId ?? 0;
                        checkDataExist.ModifiedDate = DateTime.Now;
                        FlowTimeKeepingRepo.Update(checkDataExist);
                        await FlowTimeKeepingRepo.SaveChangeAsync();
                    }
                    else
                    {
                        checkDataExist = new FlowTimeKeeping();
                        checkDataExist.StaffId = v;
                        checkDataExist.SalonId = salonId;
                        checkDataExist.DoUserId = doUserId;
                        checkDataExist.WorkDate = WorkDate;
                        checkDataExist.CreatedDate = DateTime.Now;
                        checkDataExist.IsDelete = 0;
                        checkDataExist.IsEnroll = true;
                        checkDataExist.IsDelete = 0;
                        checkDataExist.WorkTimeId = workTimeId;
                        checkDataExist.HourIds = strHourId;
                        checkDataExist.WorkHour = 0;
                        checkDataExist.Type = departmentId ?? 0;
                        FlowTimeKeepingRepo.Add(checkDataExist);
                        await FlowTimeKeepingRepo.SaveChangeAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Add update in table SmEnrollTemp
        /// </summary>
        /// <returns></returns>
        public async Task AddUpdateSMEnrollTemp(IEnumerable<int> listStaffId, int? salonId, DateTime WorkDate)
        {
            try
            {
                foreach (var v in listStaffId)
                {
                    // check Stylist  có chuyển Salon hay không
                    var checkData = await SMEnrollTempRepo.Get(a => a.WorkDate == WorkDate
                                                             && a.StaffId == v
                                                             && a.SalonId != salonId
                                                             && a.IsEnroll == true);
                    if (checkData != null)
                    {
                        checkData.IsDelete = true;
                        checkData.IsEnroll = false;
                        checkData.ModifiedTime = DateTime.Now;
                        SMEnrollTempRepo.Update(checkData);
                        await SMEnrollTempRepo.SaveChangeAsync();
                    }
                    //check data exist
                    var checkDataExist = await SMEnrollTempRepo.Get(a => a.WorkDate == WorkDate
                                                          && a.StaffId == v
                                                          && a.SalonId == salonId);
                    if (checkDataExist != null)
                    {
                        checkDataExist.IsEnroll = true;
                        checkDataExist.WorkDate = WorkDate;
                        checkDataExist.ModifiedTime = DateTime.Now;
                        checkDataExist.IsDelete = false;
                        SMEnrollTempRepo.Update(checkDataExist);
                        await SMEnrollTempRepo.SaveChangeAsync();
                    }
                    else
                    {
                        checkDataExist = new SmEnrollTemp();
                        checkDataExist.SalonId = salonId;
                        checkDataExist.StaffId = v;
                        checkDataExist.CreatedTime = DateTime.Now;
                        checkDataExist.IsEnroll = true;
                        checkDataExist.IsDelete = false;
                        checkDataExist.WorkDate = WorkDate;
                        SMEnrollTempRepo.Add(checkDataExist);
                        await SMEnrollTempRepo.SaveChangeAsync();
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// AddUpdateSmEnrollTempHourByStaff
        /// </summary>
        /// <returns></returns>
        public async Task AddUpdateSmEnrollTempHourByStaff(int staffId, int? salonId, DateTime workDate, string strHourId)
        {
            try
            {
                //convert 
                var listHourID = strHourId.ConvertTimeKeeping();
                var index = -1;
                var obj = new SmEnrollTempHour();

                var checkDataEnrollTemp = await SMEnrollTempRepo.Get(w => w.WorkDate == workDate
                                                                        && w.StaffId == staffId
                                                                        && w.SalonId == salonId);
                if (checkDataEnrollTemp != null)
                {
                    var listEnrollTempHour = await SMEnrollTempHourRepo.GetList(a => a.EnrollId == checkDataEnrollTemp.Id);
                    foreach (var item in listHourID)
                    {
                        if (listHourID != null)
                        {
                            index = listEnrollTempHour.FindIndex(a => a.HourId == item);
                            if (index == -1)
                            {
                                obj = new SmEnrollTempHour();
                                obj.EnrollId = checkDataEnrollTemp.Id;
                                obj.HourId = item;
                                obj.IsDelete = false;
                                obj.CreatedTime = DateTime.Now;
                                SMEnrollTempHourRepo.Add(obj);
                            }
                            else
                            {
                                var sm = listEnrollTempHour[index];
                                sm.IsDelete = false;
                                sm.ModifiedTime = DateTime.Now;
                                SMEnrollTempHourRepo.Update(sm);
                            }
                        }
                        // save
                        await SMEnrollTempHourRepo.SaveChangeAsync();
                    }
                    if (listEnrollTempHour != null)
                    {
                        foreach (var item in listEnrollTempHour)
                        {
                            if (listHourID != null)
                            {
                                index = listHourID.FindIndex(f => f == item.HourId);
                                if (index == -1)
                                {
                                    item.IsDelete = true;
                                    item.ModifiedTime = DateTime.Now;
                                    SMEnrollTempHourRepo.Update(item);
                                }
                            }
                            //save
                            await SMEnrollTempHourRepo.SaveChangeAsync();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// add Update in table SMEnrollTempHour where listStaff
        /// </summary>
        /// <returns></returns>
        public async Task AddUpdateSMEnrollTempHourListStaff(IEnumerable<int> listStaffId, int? salonId, DateTime workDate, string strHourId)
        {
            try
            {
                //convert 
                var listHourId = strHourId.ConvertTimeKeeping();
                var index = -1;
                var obj = new SmEnrollTempHour();
                foreach (var v in listStaffId)
                {
                    var checkDataEnrollTemp = await SMEnrollTempRepo.Get(w => w.WorkDate == workDate
                                                                            && w.StaffId == v
                                                                            && w.SalonId == salonId);
                    if (checkDataEnrollTemp != null)
                    {
                        var listEnrollTempHour = await SMEnrollTempHourRepo.GetList(a => a.EnrollId == checkDataEnrollTemp.Id);
                        foreach (var item in listHourId)
                        {
                            index = listEnrollTempHour.FindIndex(f => f.HourId == item);
                            if (index == -1)
                            {
                                obj = new SmEnrollTempHour();
                                obj.EnrollId = checkDataEnrollTemp.Id;
                                obj.HourId = item;
                                obj.IsDelete = false;
                                obj.CreatedTime = DateTime.Now;
                                SMEnrollTempHourRepo.Add(obj);
                            }
                            else
                            {
                                var sm = listEnrollTempHour[index];
                                sm.IsDelete = false;
                                sm.ModifiedTime = DateTime.Now;
                                SMEnrollTempHourRepo.Update(sm);
                            }
                        }
                        // save
                        await SMEnrollTempHourRepo.SaveChangeAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Get list hour Id
        /// </summary>
        /// <param name="workTimeId"></param>
        /// <param name="salonId"></param>
        /// <returns></returns>
        public async Task<string> GetListHourId(int workTimeId, int salonId)
        {
            string str = "";
            try
            {
                //get data worktime
                var data = await WorkTimeRepo.Get(a => a.Id == workTimeId && a.IsDelete == 0 && a.Publish == true);
                if (data != null)
                {
                    string strStratWorkHour = Convert.ToString(data.StrartTime);
                    string strEndWorkHour = Convert.ToString(data.EnadTime);
                    string strLunchhour = Convert.ToString(data.Lunchhour);
                    string strLunchhour2 = Convert.ToString(data.Lunchhour2);
                    TimeSpan StartWorkHour = TimeSpan.Parse(strStratWorkHour);
                    TimeSpan EndWorkHour = TimeSpan.Parse(strEndWorkHour);
                    TimeSpan Lunchhour = TimeSpan.Parse(strLunchhour);
                    TimeSpan Lunchhour2 = TimeSpan.Parse(strLunchhour2);
                    //Get book hour in salon
                    var bookHours = await BookHoursRepo.GetList(a => a.SalonId == salonId
                                                             && a.IsDelete == 0
                                                             && a.Publish == true
                                                             && a.HourFrame >= StartWorkHour
                                                             && a.HourFrame <= EndWorkHour
                                                             && a.HourFrame != Lunchhour
                                                             && a.HourFrame != Lunchhour2);
                    int _Count = Convert.ToInt32(bookHours.Count);
                    if (_Count > 0)
                    {
                        for (int i = 0; i < _Count; i++)
                        {
                            str += bookHours[i].Id + ",";
                        }
                        if (str.EndsWith(","))
                            str = str.Remove(str.Length - 1, 1);
                    }
                }

                return str;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Insert salary income
        /// </summary>
        /// <param name="workDate"></param>
        /// <param name="salonId"></param>
        /// <param name="staffId"></param>
        /// <param name="workHour"></param>
        /// <returns></returns>
        public async Task InsertSalaryIncome(List<int> lstStaffId, int salonId, DateTime workDate)
        {
            try
            {
                for (int i = 0; i < lstStaffId.Count; i++)
                {
                    var objStaff = await StaffRepo.Get(r => r.Id == lstStaffId[i]
                                                        && r.SalaryByPerson != true
                                                        && r.RequireEnroll == true);
                    //&& r.Type != 9);
                    if (objStaff != null)
                    {
                        // lay thang 
                        int Month = workDate.Month;
                        //lay nam
                        int Year = workDate.Year;
                        //lay ngay trong thang _ nam
                        int Days = DateTime.DaysInMonth(Year, Month);
                        var objIncome = await SalaryIncomeRepo.Get(r => r.StaffId == objStaff.Id
                                                                        && r.WorkDate == workDate
                                                                        && r.IsDeleted == false);
                        //Add
                        if (objIncome == null)
                        {
                            //CalculateSalaryFixedAndBehave
                            var objAdd = await CalculateSalaryFixedAndBehave(workDate, Days, lstStaffId[i], objStaff.SkillLevel ?? 0, objStaff.Type ?? 0);

                            if (objAdd != null)
                            {
                                objAdd.CreatedTime = DateTime.Now;
                                objAdd.ServiceSalary = 0;
                                objAdd.ProductSalary = 0;
                                objAdd.RatingPoint = 0;
                                objAdd.BillNormal = 0;
                                objAdd.BillNormalGreat = 0;
                                objAdd.BillNormalGood = 0;
                                objAdd.BillNormalBad = 0;
                                objAdd.BillNormalNoRating = 0;
                                objAdd.BillSpecial = 0;
                                objAdd.BillSpecialGreat = 0;
                                objAdd.BillSpecialGood = 0;
                                objAdd.BillSpecialBad = 0;
                                objAdd.BillSpecialNoRating = 0;
                                objAdd.WorkDate = workDate;
                                objAdd.IsDeleted = false;
                                objAdd.StaffId = lstStaffId[i];
                                objAdd.LevelId = objStaff.SkillLevel;
                                objAdd.OvertimeSalary = 0;
                                objAdd.SalonId = salonId;
                                objAdd.Month = Month;
                                objAdd.Year = Year;
                                SalaryIncomeRepo.Add(objAdd);
                                await SalaryIncomeRepo.SaveChangeAsync();
                            }

                        }
                        //Update
                        else
                        {
                            // CalculateSalaryFixedAndBehave
                            var recordIncome = await CalculateSalaryFixedAndBehave(workDate, Days, lstStaffId[i], objStaff.SkillLevel ?? 0, objStaff.Type ?? 0);
                            objIncome.WorkDate = workDate;
                            objIncome.IsDeleted = false;
                            objIncome.LevelId = objStaff.SkillLevel;
                            objIncome.OvertimeSalary = 0;
                            objIncome.SalonId = salonId;
                            objIncome.Month = Month;
                            objIncome.Year = Year;
                            objIncome.FixedSalary = recordIncome.FixedSalary;
                            objIncome.BehaveSalary = recordIncome.BehaveSalary;
                            objIncome.AllowanceSalary = recordIncome.AllowanceSalary;
                            SalaryIncomeRepo.Update(objIncome);
                            await SalaryIncomeRepo.SaveChangeAsync();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Update over time salary
        /// </summary>
        /// <returns></returns>
        public async Task UpdateOverTimeSalary(int staffId, string workDate, int workTimeId, int workHour)
        {
            try
            {
                var WorkDate = Convert.ToDateTime(workDate, DatetimeExtension.GetCultureInfo());
                //
                var objStaff = await StaffRepo.GetById(staffId);
                double overTime = 0;
                var objSalaryConfig = await SalaryConfigRepo.Get(r => r.DepartmentId == objStaff.Type
                                                                && r.LevelId == objStaff.SkillLevel
                                                                && r.IsDeleted == false);

                if (objSalaryConfig != null)
                {
                    overTime = objSalaryConfig.OvertimeSalary ?? 0;
                }

                var objSalaryIncome = await SalaryIncomeRepo.Get(r => r.StaffId == staffId && r.WorkDate == WorkDate);

                if (objSalaryIncome != null)
                {
                    var objSalon = await SalonRepo.GetById(objSalaryIncome.SalonId ?? 0);
                    if (objSalon != null)
                    {
                        if (Array.IndexOf(new int[] { 1, 2 }, objStaff.Type ?? 0) == 0)
                        {
                            if (objSalon.IsPartTimeHours == true)
                            {
                                objSalaryIncome.OvertimeSalary = workHour * overTime;
                            }
                            else
                            {
                                objSalaryIncome.OvertimeSalary = 0;
                            }
                        }
                        else
                        {
                            objSalaryIncome.OvertimeSalary = workHour * overTime;
                        }
                        //Update
                        SalaryIncomeRepo.Update(objSalaryIncome);
                        // save
                        await SalaryIncomeRepo.SaveChangeAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// CalculateSalaryFixedAndBehave
        /// </summary>
        /// <param name="date"></param>
        /// <param name="days"></param>
        /// <param name="staffId"></param>
        /// <param name="skillLevel"></param>
        /// <param name="deparmentId"></param>
        /// <returns></returns>
        public async Task<SalaryIncome> CalculateSalaryFixedAndBehave(DateTime date, int days, int staffId, int skillLevel, int deparmentId)
        {
            try
            {
                var objIncome = new SalaryIncome();

                double fixedSalary = 0;
                double behaveSalary = 0;
                double allowanceSalary = 0;
                double configFixedSalary = 0;
                double configSalaryOscillation = 0;
                var timeFrom = new DateTime(date.Year, date.Month, 1);
                var timeTo = timeFrom.AddMonths(1).AddDays(-1);
                var timeKeeping = await FlowTimeKeepingRepo.Get(r => r.WorkDate == date && r.StaffId == staffId && r.IsEnroll == true);

                var objSalaryConfigStaff = await SalaryConfigStaffRepo.GetByStaffId(staffId);
                configSalaryOscillation = objSalaryConfigStaff == null ? 0 : (objSalaryConfigStaff.FixSalaryOscillation ?? 0);

                var objConfig = await SalaryConfigRepo.Get(r => r.LevelId == skillLevel && r.DepartmentId == deparmentId);
                configFixedSalary = objConfig == null ? 0 : (objConfig.FixedSalary ?? 0);

                fixedSalary = configFixedSalary + configSalaryOscillation;
                behaveSalary = objConfig == null ? 0 : (objConfig.BehaveSalary ?? 0);
                //Count Timekeeping
                int totalTimeKeeping = await FlowTimeKeepingRepo.GetTotalKeeping(timeFrom, date, staffId);
                if (timeKeeping != null)
                {
                    int iTimeKeeping = await SalaryIncomeRepo.CountSalaryIncome(timeFrom, timeTo, staffId);
                    if (fixedSalary > 0 || behaveSalary > 0)
                    {
                        //Nhỏ hơn ngày trong tháng trừ 4
                        if (totalTimeKeeping <= (days - 4) && (deparmentId == 1 || deparmentId == 2))
                        {
                            //Lương bản ghi tính bình thường
                            //Kiểm tra ca làm
                            if (timeKeeping.WorkTimeId == 1 || timeKeeping.WorkTimeId == 2 || timeKeeping.WorkTimeId == 3)
                            {
                                objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                            }
                            else if (timeKeeping.WorkTimeId == 5 || timeKeeping.WorkTimeId == 6)
                            {
                                objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                            }
                            //Cập nhật lương không phải đặc biệt về 0
                            var salaryIncomes = await SalaryIncomeRepo.SalaryAndTimeKeepingDes(timeFrom.AddDays(days - 4), timeTo, staffId);
                            if (salaryIncomes != null && iTimeKeeping >= (days - 4))
                            {
                                if (salaryIncomes.WorkDate >= timeTo.AddDays(-3))
                                {
                                    salaryIncomes.FixedSalary = 0;
                                    salaryIncomes.BehaveSalary = 0;
                                    SalaryIncomeRepo.Update(salaryIncomes);
                                    await SalaryIncomeRepo.SaveChangeAsync();
                                }
                            }

                            //Cập nhật lương đặc biệt về bình thường
                            //item 1 la salaryincome, item 2 la flowtimekeeping
                            var salaryIncome = await SalaryIncomeRepo.SalaryAndTimeKeepingAsc(timeFrom.AddDays(days - 4), timeTo, staffId);
                            if (salaryIncome.Item1 != null && iTimeKeeping < (days - 4))
                            {
                                //Kiểm tra ca làm
                                if (salaryIncome.Item1.WorkDate >= timeTo.AddDays(-3))
                                {
                                    if (salaryIncome.Item2.WorkTimeId == 1
                                        || salaryIncome.Item2.WorkTimeId == 2
                                        || salaryIncome.Item2.WorkTimeId == 3)
                                    {
                                        salaryIncome.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                        salaryIncome.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                                    }
                                    else if (salaryIncome.Item2.WorkTimeId == 5 || salaryIncome.Item2.WorkTimeId == 6)
                                    {
                                        salaryIncome.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                        salaryIncome.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                                    }
                                    SalaryIncomeRepo.Update(salaryIncome.Item1);
                                    await SalaryIncomeRepo.SaveChangeAsync();
                                }
                            }
                        }
                        else if (totalTimeKeeping <= (days - 4) && (deparmentId == 4 || deparmentId == 5 || deparmentId == 6))
                        {
                            //Kiểm tra ca làm
                            if (timeKeeping.WorkTimeId == 1 || timeKeeping.WorkTimeId == 2 ||
                                timeKeeping.WorkTimeId == 3)
                            {
                                objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                            }
                            else if (timeKeeping.WorkTimeId == 5 || timeKeeping.WorkTimeId == 6)
                            {
                                objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                            }

                            var salaryIncome456 = await SalaryIncomeRepo.SalaryAndTimeKeepingAsc456(timeFrom.AddDays(days - 4), timeTo, staffId,
                                    objIncome.FixedSalary ?? 0);
                            if (salaryIncome456.Item1 != null && iTimeKeeping < (days - 4))
                            {
                                if (salaryIncome456.Item2.WorkTimeId == 1 || salaryIncome456.Item2.WorkTimeId == 2 ||
                                    salaryIncome456.Item2.WorkTimeId == 3)
                                {
                                    salaryIncome456.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                    salaryIncome456.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                                }
                                else if (salaryIncome456.Item2.WorkTimeId == 5 || salaryIncome456.Item2.WorkTimeId == 6)
                                {
                                    salaryIncome456.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                    salaryIncome456.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                                }
                                SalaryIncomeRepo.Update(salaryIncome456.Item1);
                                await SalaryIncomeRepo.SaveChangeAsync();
                            }

                        }
                        //Staff type = 4,6,5
                        else if (totalTimeKeeping > (days - 4) && deparmentId == 4 || deparmentId == 5 || deparmentId == 6)
                        {
                            if (date < timeTo.AddDays(-3))
                            {
                                var salaryIncome456 = await SalaryIncomeRepo.SalaryAndTimeKeepingDes456(timeFrom.AddDays(days - 4), timeTo,
                                        staffId, fixedSalary / (days - 4));
                                if (salaryIncome456.Item1 != null)
                                {
                                    if (date >= timeTo.AddDays(-3))
                                    {
                                        // Kiểm tra ca làm
                                        if (salaryIncome456.Item2.WorkTimeId == 1 || salaryIncome456.Item2.WorkTimeId == 2 || salaryIncome456.Item2.WorkTimeId == 3)
                                        {
                                            salaryIncome456.Item1.FixedSalary = (fixedSalary / (days - 4)) * 2 / 8 * 8;
                                            salaryIncome456.Item1.BehaveSalary = (behaveSalary / (days - 4)) * 2 / 8 * 8;
                                        }
                                        else if (salaryIncome456.Item2.WorkTimeId == 5 || salaryIncome456.Item2.WorkTimeId == 6)
                                        {
                                            salaryIncome456.Item1.FixedSalary = (fixedSalary / (days - 4)) * 2 / 8 * 6;
                                            salaryIncome456.Item1.BehaveSalary = (behaveSalary / (days - 4)) * 2 / 8 * 6;
                                        }
                                        SalaryIncomeRepo.Update(salaryIncome456.Item1);
                                        await SalaryIncomeRepo.SaveChangeAsync();

                                    }
                                }
                                //Kiểm tra ca làm
                                if (timeKeeping.WorkTimeId == 1 || timeKeeping.WorkTimeId == 2 ||
                                    timeKeeping.WorkTimeId == 3)
                                {
                                    objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                    objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                                }
                                else if (timeKeeping.WorkTimeId == 5 || timeKeeping.WorkTimeId == 6)
                                {
                                    objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                    objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                                }
                            }
                            else
                            {
                                if (timeKeeping.WorkTimeId == 1 || timeKeeping.WorkTimeId == 2 ||
                                    timeKeeping.WorkTimeId == 3)
                                {
                                    objIncome.FixedSalary = (fixedSalary / (days - 4)) * 2 / 8 * 8;
                                    objIncome.BehaveSalary = (behaveSalary / (days - 4)) * 2 / 8 * 8;
                                }
                                else if (timeKeeping.WorkTimeId == 5 || timeKeeping.WorkTimeId == 6)
                                {
                                    objIncome.FixedSalary = (fixedSalary / (days - 4)) * 2 / 8 * 6;
                                    objIncome.BehaveSalary = (behaveSalary / (days - 4)) * 2 / 8 * 6;
                                }
                            }
                        }
                        //Staff type = 1,2
                        else if (totalTimeKeeping > (days - 4) && (deparmentId == 1 || deparmentId == 2))
                        {
                            if (date < timeTo.AddDays(-3))
                            {
                                var salaryIncomes = await SalaryIncomeRepo.SalaryAndTimeKeepingDes(timeFrom.AddDays(days - 4), timeTo, staffId);
                                if (salaryIncomes != null)
                                {
                                    if (salaryIncomes.WorkDate >= timeTo.AddDays(-3))
                                    {
                                        salaryIncomes.BehaveSalary = 0;
                                        salaryIncomes.FixedSalary = 0;
                                        SalaryIncomeRepo.Update(salaryIncomes);
                                        await SalaryIncomeRepo.SaveChangeAsync();
                                    }
                                }
                                //Kiểm tra ca làm
                                if (timeKeeping.WorkTimeId == 1 || timeKeeping.WorkTimeId == 2 ||
                                    timeKeeping.WorkTimeId == 3)
                                {
                                    objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                    objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                                }
                                else if (timeKeeping.WorkTimeId == 5 || timeKeeping.WorkTimeId == 6)
                                {
                                    objIncome.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                    objIncome.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                                }

                            }
                            else
                            {
                                objIncome.FixedSalary = 0;
                                objIncome.BehaveSalary = 0;
                            }
                        }

                    }
                    else
                    {
                        objIncome.FixedSalary = 0;
                        objIncome.BehaveSalary = 0;
                    }

                    var salaryConfig =
                        await SalaryConfigRepo.Get(r => r.LevelId == skillLevel && r.DepartmentId == deparmentId);
                    allowanceSalary = salaryConfig == null ? 0 : (salaryConfig.AllowanceSalary ?? 0);
                    if (allowanceSalary > 0)
                    {
                        objIncome.AllowanceSalary = allowanceSalary / (days - 4);
                    }
                    else
                    {
                        objIncome.AllowanceSalary = 0;
                    }
                }
                else
                {
                    objIncome.AllowanceSalary = 0;
                    objIncome.FixedSalary = 0;
                    objIncome.BehaveSalary = 0;

                    int isalaryIncome = await SalaryIncomeRepo.CountSalaryIncome(timeFrom, timeTo, staffId);
                    if (fixedSalary > 0 || behaveSalary > 0)
                    {
                        if (deparmentId == 1 || deparmentId == 2)
                        {
                            var salaryIncome =
                               await SalaryIncomeRepo.SalaryAndTimeKeepingAsc(timeFrom.AddDays(days - 4), timeTo, staffId);
                            if (salaryIncome.Item1 != null && isalaryIncome < (days - 4))
                            {
                                // Kiểm tra ca làm
                                if (salaryIncome.Item2.WorkTimeId == 1 || salaryIncome.Item2.WorkTimeId == 2 ||
                                    salaryIncome.Item2.WorkTimeId == 3)
                                {
                                    salaryIncome.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                    salaryIncome.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                                }
                                else if (salaryIncome.Item2.WorkTimeId == 5 || salaryIncome.Item2.WorkTimeId == 6)
                                {
                                    salaryIncome.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                    salaryIncome.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                                }
                                SalaryIncomeRepo.Update(salaryIncome.Item1);
                                await SalaryIncomeRepo.SaveChangeAsync();
                            }
                        }

                        if (deparmentId == 4 || deparmentId == 5 || deparmentId == 6)
                        {
                            var salaryIncome456 =
                                await SalaryIncomeRepo.SalaryAndTimeKeepingAsc456(timeFrom.AddDays(days - 4), timeTo,
                                    staffId, fixedSalary / (days - 4));
                            if (salaryIncome456.Item1 != null && isalaryIncome < (days - 4))
                            {
                                // Kiểm tra ca làm
                                if (salaryIncome456.Item2.WorkTimeId == 1 || salaryIncome456.Item2.WorkTimeId == 2 ||
                                    salaryIncome456.Item2.WorkTimeId == 3)
                                {
                                    salaryIncome456.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 8;
                                    salaryIncome456.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 8;
                                }
                                else if (salaryIncome456.Item2.WorkTimeId == 5 || salaryIncome456.Item2.WorkTimeId == 6)
                                {
                                    salaryIncome456.Item1.FixedSalary = (fixedSalary / (days - 4)) / 8 * 6;
                                    salaryIncome456.Item1.BehaveSalary = (behaveSalary / (days - 4)) / 8 * 6;
                                }
                                SalaryIncomeRepo.Update(salaryIncome456.Item1);
                                await SalaryIncomeRepo.SaveChangeAsync();
                            }
                        }
                    }
                }

                return objIncome;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Delete timekeeping
        /// </summary>
        /// <returns></returns>
        public async Task DeleteTimekeeping(int staffId, int salonId, string workDate)
        {
            var WorkDate = Convert.ToDateTime(workDate, DatetimeExtension.GetCultureInfo());
            // Xóa toàn bộ bản ghi chấm công của nhân viên
            var listTimekeeping = await FlowTimeKeepingRepo.GetList(r => r.WorkDate == WorkDate
                                                                    && r.StaffId == staffId
                                                                    && r.SalonId == salonId);
            foreach (var item in listTimekeeping)
            {
                item.IsDelete = 1;
                item.IsEnroll = false;
                item.WorkHour = 0;
                item.ModifiedDate = DateTime.Now;
            }

            FlowTimeKeepingRepo.UpdateRange(listTimekeeping);

            //await FlowTimeKeepingRepo.SaveChangeAsync();
            // Xoa SM_EnrollTemp
            var listSmEnrollTemp = await SMEnrollTempRepo.GetList(r => r.WorkDate == WorkDate &&
                                                                r.StaffId == staffId &&
                                                                r.SalonId == salonId);
            if (listSmEnrollTemp.Count > 0)
            {
                foreach (var item in listSmEnrollTemp)
                {
                    item.IsDelete = true;
                    item.ModifiedTime = DateTime.Now;
                }
                // update 
                SMEnrollTempRepo.UpdateRange(listSmEnrollTemp);

                // Xóa SmEnrollHour
                var listSmEnrollTempId = listSmEnrollTemp.Select(r => r.Id).ToList();
                var listSmEnrollTempHour = await SMEnrollTempHourRepo.GetList(r => listSmEnrollTempId.Contains(r.EnrollId ?? 0));
                foreach (var item in listSmEnrollTempHour)
                {
                    item.IsDelete = true;
                    item.ModifiedTime = DateTime.Now;
                }
                //Update range
                SMEnrollTempHourRepo.UpdateRange(listSmEnrollTempHour);
            }
            // save
            await SMEnrollTempRepo.SaveChangeAsync();
        }
    }
}
