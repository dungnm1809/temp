﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APITimekeeping.Models.CustomeModel
{
    public class OutPutModel
    {
        /// <summary>
        /// MainFlowTimeKeeping
        /// </summary>
        public class MainFlowTimeKeeping
        {
            public int WorkTimeId { get; set; }
            public int TotalTime { get; set; }
            public string WorkName { get; set; }
            public List<FlowTimeKeepingHour> Hours { get; set; }
        }

        /// <summary>
        /// FlowTimeKeepingHour
        /// </summary>
        public partial class FlowTimeKeepingHour
        {
            public int HourId { get; set; }
            public string Hour { get; set; }
            public string HourFrame { get; set; }
            public bool Iskeeping { get; set; }
            public bool IsOverTime { get; set; }

        }

        /// <summary>
        /// output worktime
        /// </summary>
        public class OutputWorkTime
        {
            public List<OutPutFlowTimeKeeping> Ca1 { get; set; }
            public List<OutPutFlowTimeKeeping> Ca2 { get; set; }
            public List<OutPutFlowTimeKeeping> Ca3 { get; set; }
            public List<OutPutFlowTimeKeeping> Ca11 { get; set; }
            public List<OutPutFlowTimeKeeping> Ca31 { get; set; }
        }

        /// <summary>
        /// OutPutFlowTimeKeeping
        /// </summary>
        public partial class OutPutFlowTimeKeeping
        {
            public string WorkDate { get; set; }
            public int StaffId { get; set; }
            public string StaffName { get; set; }
            public int SalonTimekeepingId { get; set; }
            public int SalonId { get; set; }
            public int SalonIdWorking { get; set; }
            public string SalonName { get; set; }
            public int? DepartmentId { get; set; }
            public string DepartmentName { get; set; }
            public string ShortName { get; set; }
            public string TimekeepingShortName { get; set; }
            public string NoteStatus { get; set; }
            public string NoteStatusSalonCurrent { get; set; }
            public string StaffStatus { get; set; }
            public int? Parttime { get; set; }
            public int? WorkHour { get; set; }
            public int? WorkTimeId { get; set; }
            public string Color { get; set; }
            public string HourIds { get; set; }
            //public string HourIds { get; set; }
            //public List<OutputBookHour> bookHour { get; set; }
        }

        /// <summary>
        /// OutputBookHour
        /// </summary>
        public class OutputBookHour
        {
            public int Id { get; set; }
            public string Hour { get; set; }
        }

        /// <summary>
        /// Output_Staff
        /// </summary>
        public class Output_Staff
        {
            public int Id { get; set; }
            public string FullName { get; set; }
            public int SalonId { get; set; }
            public int DepartmentId { get; set; }
            public string DepartmentName { get; set; }
            public int SalonIdWorking { get; set; }
            public string NoteStatusSalonCurrent { get; set; }
        }

        /// <summary>
        /// List salon
        /// </summary>
        public class Output_Salon
        {
            public int Id { get; set; }
            public string SalonName { get; set; }
        }

    }
}
