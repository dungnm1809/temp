﻿using System;
using System.Collections.Generic;

namespace APITimekeeping.Models.Solution_30Shine
{
    public partial class ServiceTemp
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public bool IsExfoliate { get; set; }
        public bool IsMasked { get; set; }
        public bool IsDelete { get; set; }
        public DateTime CreatedTime { get; set; }
        public DateTime? ModifiedTime { get; set; }
    }
}
