﻿using System;
using System.Collections.Generic;

namespace APITimekeeping.Models.Solution_30Shine
{
    public partial class HairAttributeProduct
    {
        public int Id { get; set; }
        public string HairAttributeId { get; set; }
        public string HairAttributeIdJson { get; set; }
        public string ProductId { get; set; }
        public bool? IsDelete { get; set; }
        public string Description { get; set; }
        public string Title { get; set; }
        public Guid? Uid { get; set; }
        public byte? MigrateStatus { get; set; }
    }
}
