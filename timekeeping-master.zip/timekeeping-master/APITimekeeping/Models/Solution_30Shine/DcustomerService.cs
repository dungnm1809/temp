﻿using System;
using System.Collections.Generic;

namespace APITimekeeping.Models.Solution_30Shine
{
    public partial class DcustomerService
    {
        public int IdCustomerUseService { get; set; }
        public int CustomerId { get; set; }
        public int BillId { get; set; }
        public int ServiceId { get; set; }
        public int ServicePrice { get; set; }
        public int ServiceQuantity { get; set; }
        public int? VoucherPercent { get; set; }
        public DateTime DateOfBill { get; set; }
        public int SalonId { get; set; }
    }
}
