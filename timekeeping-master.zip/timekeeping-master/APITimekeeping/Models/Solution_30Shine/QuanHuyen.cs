﻿using System;
using System.Collections.Generic;

namespace APITimekeeping.Models.Solution_30Shine
{
    public partial class QuanHuyen
    {
        public int Id { get; set; }
        public int? TinhThanhId { get; set; }
        public string TenQuanHuyen { get; set; }
        public int? ThuTu { get; set; }
        public int? TrangThai { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public Guid? Uid { get; set; }
        public byte? MigrateStatus { get; set; }
    }
}
