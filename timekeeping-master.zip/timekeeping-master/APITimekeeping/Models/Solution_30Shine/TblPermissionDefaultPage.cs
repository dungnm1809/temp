﻿using System;
using System.Collections.Generic;

namespace APITimekeeping.Models.Solution_30Shine
{
    public partial class TblPermissionDefaultPage
    {
        public int Id { get; set; }
        public int? MenuId { get; set; }
        public string MenuLink { get; set; }
        public int? PId { get; set; }
        public Guid? Uid { get; set; }
        public byte? MigrateStatus { get; set; }
    }
}
