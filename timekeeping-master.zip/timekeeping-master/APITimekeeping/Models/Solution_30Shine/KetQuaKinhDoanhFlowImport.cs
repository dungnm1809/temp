﻿using System;
using System.Collections.Generic;

namespace APITimekeeping.Models.Solution_30Shine
{
    public partial class KetQuaKinhDoanhFlowImport
    {
        public int Id { get; set; }
        public int? KqkdsalonId { get; set; }
        public int? KqkditemId { get; set; }
        public long? Value { get; set; }
        public DateTime? ImportDate { get; set; }
        public DateTime? CreatedTime { get; set; }
        public DateTime? ModifiedTime { get; set; }
        public bool? IsDelete { get; set; }
        public string Note { get; set; }
        public Guid? Uid { get; set; }
        public byte? MigrateStatus { get; set; }
    }
}
