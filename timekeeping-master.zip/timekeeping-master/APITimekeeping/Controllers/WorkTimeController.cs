﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Repository.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace APITimekeeping.Controllers
{
    [Produces("application/json")]
    [Route("api/work-time")]
    public class WorkTimeController : Controller
    {
        private ILogger<WorkTimeController> Logger { get; }
        private readonly IPushNotice PushNotice;
        private readonly IWorkTimeRepo WorkTimeRepo;
        public WorkTimeController(ILogger<WorkTimeController> logger,
            IPushNotice pushNotice,
            IWorkTimeRepo workTimeRepo)
        {
            Logger = logger;
            PushNotice = pushNotice;
            WorkTimeRepo = workTimeRepo;
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetList()
        {
            try
            {
                var data = await WorkTimeRepo.GetList(r => r.IsDelete == 0
                                                && r.Publish == true
                                                && r.Id != AppConstants.WorktimeId);
                if (data == null || data.Count <= 0)
                {
                    return BadRequest(new { messaage = "Hệ thống bị lỗi!" });
                }

                return Ok(data.Select(a => new
                {
                    Id = a.Id,
                    Name = a.WName,
                    StartTime = a.StrartTime.Value.ToString().Substring(0, 5).Replace(":", "h"),
                    EndTime = a.EnadTime.Value.ToString().Substring(0, 5).Replace(":", "h")
                }).OrderBy(o => o.Name));
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }
    }
}