﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Repository.Interface;
using APITimekeeping.Service;
using APITimekeeping.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using static APITimekeeping.Models.CustomeModel.InputModel;

namespace APITimekeeping.Controllers
{
    [Produces("application/json")]
    [Route("api/flow-time-keeping-part-time")]
    public class FlowTimeKeepingPartTimeController : Controller
    {
        private ILogger<FlowTimeKeepingPartTimeController> Logger { get; }
        private readonly IPushNotice PushNotice;
        private readonly IFlowTimeKeepingRepo FlowTimeKeepingRepo;
        private readonly IBookHoursRepo BookHoursRepo;
        private readonly IWorkTimeRepo WorkTimeRepo;
        private readonly IStaffRepo StaffRepo;
        private readonly ISMEnrollTempRepo SMEnrollTempRepo;
        private readonly ISMEnrollTempHourRepo SMEnrollTempHourRepo;
        private HandleService HandleService;
        //constructor
        public FlowTimeKeepingPartTimeController(ILogger<FlowTimeKeepingPartTimeController> logger,
            IPushNotice pushNotice,
            IFlowTimeKeepingRepo flowTimeKeepingRepo,
            IBookHoursRepo bookHoursRepo,
            IWorkTimeRepo workTimeRepo,
            IStaffRepo staffRepo,
            ISMEnrollTempRepo sMEnrollTempRepo,
            ISMEnrollTempHourRepo sMEnrollTempHourRepo,
            HandleService handleService)
        {
            Logger = logger;
            PushNotice = pushNotice;
            FlowTimeKeepingRepo = flowTimeKeepingRepo;
            BookHoursRepo = bookHoursRepo;
            WorkTimeRepo = workTimeRepo;
            StaffRepo = staffRepo;
            SMEnrollTempRepo = sMEnrollTempRepo;
            SMEnrollTempHourRepo = sMEnrollTempHourRepo;
            HandleService = handleService;
        }

        /// <summary>
        /// update partime use erp
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "salonId": 4,
        ///         "staffId": 182,
        ///         "doUserId": 2671,
        ///         "workDate": "2018/10/30",
        ///         "hourIds":"57,58,59,60,61",
        ///         "listHourFrame": "08:30:00,09:00:00,09:30:00,10:00:00,10:30:00"
        ///     }
        ///        
        /// </remarks>
        [HttpPut]
        public async Task<IActionResult> UpdatePartTime([FromBody] QueryPartTime input)
        {
            try
            {
                if (input.salonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (input.staffId <= 0)
                {
                    return BadRequest(new { message = "StaffId not exist!" });
                }
                if (string.IsNullOrEmpty(input.workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                if (input.doUserId < 0)
                {
                    return BadRequest(new { message = "UserId not exist!" });
                }
                if (string.IsNullOrEmpty(input.listHourFrame))
                {
                    return BadRequest(new { message = "List HourFrame not exist!" });
                }
                if (string.IsNullOrEmpty(input.hourIds))
                {
                    return BadRequest(new { message = "HourIds not exist!" });
                }
                int _WorkHour = 0;
                int _WorkHourTemp = 0;
                var workDate = Convert.ToDateTime(input.workDate, DatetimeExtension.GetCultureInfo()).Date;

                // lấy bản ghi của nhân viên chấm công
                var timeKeeping = await FlowTimeKeepingRepo.Get(w => w.SalonId == input.salonId
                                                                && w.StaffId == input.staffId
                                                                && w.WorkDate == workDate);

                if (timeKeeping == null)
                {
                    return BadRequest(new { message = "Data does not exist!" });
                }

                //check nhân viên có thuộc ca gãy hay không?
                if (timeKeeping.WorkTimeId != 5 && timeKeeping.WorkTimeId != 6)
                {
                    //tìm ca làm việc của nhân viên
                    var workTime = await WorkTimeRepo.GetById((int)timeKeeping.WorkTimeId);
                    //convert string to array
                    string[] _ListHourFrame = input.listHourFrame.Split(',');
                    if (_ListHourFrame.Length > 0)
                    {
                        for (int i = 0; i < _ListHourFrame.Length; i++)
                        {
                            TimeSpan time = TimeSpan.Parse(_ListHourFrame[i]);
                            var a = _ListHourFrame[i];
                            // check có phải tăng ca hay không
                            if (time < workTime.StrartTime || time > workTime.EnadTime)
                            {
                                _WorkHourTemp = _WorkHourTemp + 1;
                            }
                        }
                    }
                    // tính toán giờ tăng ca của nhân viên
                    _WorkHour = _WorkHourTemp / 2;
                    // update
                    timeKeeping.ModifiedDate = DateTime.Now;
                    timeKeeping.HourIds = input.hourIds;
                    timeKeeping.DoUserId = input.doUserId;
                    timeKeeping.WorkHour = _WorkHour;
                    FlowTimeKeepingRepo.Update(timeKeeping);
                    //save
                    await FlowTimeKeepingRepo.SaveChangeAsync();
                    // AddUpdateSmEnrollTempHourByStaff
                    await HandleService.AddUpdateSmEnrollTempHourByStaff(input.staffId, input.salonId, workDate, input.hourIds);
                    //return
                    return Ok(new { mesage = "Success", status = 1, hour = _WorkHour });
                }
                else
                {
                    return BadRequest(new { message = "Ca gãy không được chấm tăng ca" });
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// update partime by app
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "salonId": 4,
        ///         "staffId": 182,
        ///         "doUserId": 2671,
        ///         "workDate": "2018/10/30",
        ///         "hourIds":"57,58,59,60,61",
        ///         "listHourFrame": "08:30:00,09:00:00,09:30:00,10:00:00,10:30:00",
        ///         "workTimeId": 1
        ///     }
        ///        
        /// </remarks>
        [HttpPut("update-parttime-by-app")]
        public async Task<IActionResult> UpdatePartTimeByApp([FromBody] QueryPartTime input)
        {
            try
            {
                if (input.salonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (input.staffId <= 0)
                {
                    return BadRequest(new { message = "StaffId not exist!" });
                }
                if (string.IsNullOrEmpty(input.workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                if (input.doUserId < 0)
                {
                    return BadRequest(new { message = "UserId not exist!" });
                }
                if (string.IsNullOrEmpty(input.listHourFrame))
                {
                    return BadRequest(new { message = "List HourFrame not exist!" });
                }
                if (string.IsNullOrEmpty(input.hourIds))
                {
                    return BadRequest(new { message = "HourIds not exist!" });
                }
                int _WorkHour = 0;
                int _WorkHourTemp = 0;
                var workDate = Convert.ToDateTime(input.workDate, DatetimeExtension.GetCultureInfo()).Date;
                if ((workDate.Date > DateTime.Now.Date) || (workDate.Date == DateTime.Now.Date && workDate <= DateTime.Now && DateTime.Now <= DateTime.Now.Date.AddDays(1).AddMinutes(-60)))
                {
                    // lấy bản ghi của nhân viên chấm công
                    var timeKeeping = await FlowTimeKeepingRepo.Get(w => w.SalonId == input.salonId
                                                                && w.StaffId == input.staffId
                                                                && w.WorkDate == workDate);
                    if (timeKeeping == null)
                    {
                        return BadRequest(new { message = "Data does not exist!" });
                    }

                    //check nhân viên có thuộc ca gãy hay không?
                    if (timeKeeping.WorkTimeId != 5 && timeKeeping.WorkTimeId != 6)
                    {
                        //tìm ca làm việc của nhân viên
                        var workTime = await WorkTimeRepo.GetById((int)timeKeeping.WorkTimeId);
                        //convert string to array
                        string[] _ListHourFrame = input.listHourFrame.Split(',');
                        if (_ListHourFrame.Length > 0)
                        {
                            for (int i = 0; i < _ListHourFrame.Length; i++)
                            {
                                TimeSpan time = TimeSpan.Parse(_ListHourFrame[i]);
                                var a = _ListHourFrame[i];
                                // check có phải tăng ca hay không
                                if (time < workTime.StrartTime || time > workTime.EnadTime)
                                {
                                    _WorkHourTemp = _WorkHourTemp + 1;
                                }
                            }
                        }
                        // tính toán giờ tăng ca của nhân viên
                        _WorkHour = _WorkHourTemp / 2;
                        // update
                        timeKeeping.ModifiedDate = DateTime.Now;
                        timeKeeping.HourIds = input.hourIds;
                        timeKeeping.DoUserId = input.doUserId;
                        timeKeeping.WorkHour = _WorkHour;
                        FlowTimeKeepingRepo.Update(timeKeeping);
                        //save
                        await FlowTimeKeepingRepo.SaveChangeAsync();
                        // call update overtime salary income
                        await HandleService.UpdateOverTimeSalary(input.staffId, input.workDate, input.workTimeId, _WorkHour);
                        // AddUpdateSmEnrollTempHourByStaff
                        await HandleService.AddUpdateSmEnrollTempHourByStaff(input.staffId, input.salonId, workDate, input.hourIds);
                        // return
                        return Ok(new { mesage = "Success", status = 1 });
                    }
                    else
                    {
                        return BadRequest(new { message = "Ca gãy không được chấm tăng ca" });
                    }
                }
                else
                {
                    return BadRequest(new { message = "Đã quá giờ sửa chấm tăng ca!", status = 0 });
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }
    }
}