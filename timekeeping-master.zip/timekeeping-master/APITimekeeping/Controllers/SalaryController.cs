﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using APITimekeeping.Service;
using APITimekeeping.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using static APITimekeeping.Models.CustomeModel.InputModel;

namespace APITimekeeping.Controllers
{
    [Produces("application/json")]
    [Route("salary-income")]
    public class SalaryController : Controller
    {
        private ILogger<FlowTimeKeepingController> Logger { get; }
        private readonly IPushNotice PushNotice;
        private readonly HandleService HandleService;

        public SalaryController(ILogger<FlowTimeKeepingController> logger,
             IPushNotice pushNotice,
             HandleService handleService)
        {
            Logger = logger;
            PushNotice = pushNotice;
            HandleService = handleService;
        }

        /// <summary>
        /// Update customer
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     {
        ///         "WorkDate":"14/12/2018",
        ///         "SalonId":2,
        ///         "StaffId":16,
        ///         "WorkHour":0,
        ///     }
        ///
        /// </remarks>
        ///
        [HttpPost]
        public async Task<IActionResult> InsertSalaryInCome([FromBody] ReqSalaryIncome param)
        {
            try
            {
                if (string.IsNullOrEmpty(param.WorkDate))
                {
                    return BadRequest(new { message = "WorkDate Not Exits!" });
                }
                if (string.IsNullOrEmpty(param.StaffId))
                {
                    return BadRequest(new { message = "StaffId Not Exits!" });
                }
                if (param.SalonId <= 0)
                {
                    return BadRequest(new { message = "SalonId Not Exits!" });
                }
                //convert arr to list
                var listStaffId = param.StaffId.ConvertTimeKeeping();
                //convert workdate
                var WorkDate = Convert.ToDateTime(param.WorkDate, DatetimeExtension.GetCultureInfo());
                //call 
                await HandleService.InsertSalaryIncome(listStaffId, param.SalonId, WorkDate);

                return Ok(new { message = "Success", status = 1 });
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// UpdateOverTimeSalary
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     {
        ///         "staffId":163,
        ///         "workDate": "2018/11/05",
        ///         "workHour": 1
        ///     }
        ///
        /// </remarks>
        [HttpPut("overtime-salary")]
        public async Task<IActionResult> UpdateOverTimeSalary([FromBody] ReqDeleteTimekeeping param)
        {
            try
            {
                if (param == null)
                {
                    return BadRequest(new { message = "Param Not Exits!" });
                }
                if (param.StaffId <= 0)
                {
                    return BadRequest(new { message = "StaffId Not Exits!" });
                }
                if (string.IsNullOrEmpty(param.workDate))
                {
                    return BadRequest(new { message = "WorkDate Not Exits!" });
                }
                if (param.WorkHour < 0)
                {
                    return BadRequest(new { message = "WorkHour Not Exits!" });
                }
                // call 
                await HandleService.UpdateOverTimeSalary(param.StaffId, param.workDate, param.workTimeId, param.WorkHour);

                return Ok(new { message = "Success", status = 1 });
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

    }
}