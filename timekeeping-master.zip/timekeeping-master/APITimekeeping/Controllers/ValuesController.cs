﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Models.CustomeModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace APITimekeeping.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        private ILogger<ValuesController> Logger { get; }
        private IPushNotice PushNotice;

        public ValuesController(ILogger<ValuesController> logger, IPushNotice pushNotice)
        {
            Logger = logger;
            PushNotice = pushNotice;
        }

        // GET api/values
        [HttpGet, Authorize]
        //[HttpGet, Authorize]
        public async Task<IActionResult> Get()
        {
            try
            {
                var currentUser = HttpContext.User;
                string customerPhone = string.Empty;

                if (currentUser.FindFirst("authen") != null)
                {
                    var authen = JsonConvert.DeserializeObject<InputModel.AuthenModel>(currentUser.FindFirst("authen").Value);
                    customerPhone = currentUser.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
                }

                return Ok(customerPhone);
            }
            catch (Exception e)
            {
                return StatusCode(500, new { message = e.Message });
            }
        }

        // GET api/values/5
        [HttpGet("{id}"), Authorize]
        public IActionResult Get(int id)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest();
                }
                //TODO: find object

                //TODO: if null return NoContent

                //TODO: if object exist return ok and object
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(500, new { message = e.Message });
            }
        }

        // POST api/values
        [HttpPost, Authorize]
        public async Task<IActionResult> Post([FromBody]string value)
        {
            try
            {
                //TODO: check validate

                //TODO: if success return ok
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(500, new { message = e.Message });
            }
        }

        // PUT api/values/5
        [HttpPut("{id}"), Authorize]
        public async Task<IActionResult> Put(int id, [FromBody]string value)
        {
            try
            {
                //TODO: check validate

                //TODO: if success return ok
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(500, new { message = e.Message });
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}"), Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                //TODO: check validate

                //TODO: if success return ok
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(500, new { message = e.Message });
            }
        }

        private class TestObject
        {
            [JsonProperty(PropertyName = "Id")]
            public int Id { get; set; }

            [JsonProperty(PropertyName = "Name")]
            public string Name { get; set; }

            [JsonIgnore]
            public string Test { get; set; }
        }
        [HttpGet("test")]
        public IActionResult Test()
        {
            PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "Test group moi thanh cong");
            return Ok("thanh cong");
        }
    }
}
