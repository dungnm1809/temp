﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using APITimekeeping.Service;
using APITimekeeping.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using static APITimekeeping.Models.CustomeModel.InputModel;

namespace APITimekeeping.Controllers
{
    [Produces("application/json")]
    [Route("api/sm-enrolltemp")]
    public class SMEnrollTempController : Controller
    {
        private ILogger<SMEnrollTempController> Logger { get; }
        private readonly IPushNotice PushNotice;
        private readonly HandleService HandleService;
        //constructor
        public SMEnrollTempController(ILogger<SMEnrollTempController> logger,
                             IPushNotice pushNotice,
                             HandleService handleService
                             )
        {
            Logger = logger;
            PushNotice = pushNotice;
            HandleService = handleService;
        }

        /// <summary>
        /// add sm enrolltemp, temphour
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "salonId": 2,
        ///         "staffId": "134,163,246,406,452,597,747,763,1021,1026",
        ///         "workDate": "2018/11/01",
        ///         "workTimeId":1,
        ///         "isEnroll": true
        ///     }
        ///        
        /// </remarks>
        [HttpPost]
        public async Task<IActionResult> AddSmEroll([FromBody] InputAddEnroll input)
        {
            try
            {
                if (input.salonId <= 0 || input.staffId == "" || input.workDate == null || input.workTimeId <= 0)
                {
                    return BadRequest(new { message = "Data does not exist!" });
                }
                // get salon
                var SalonId = input.salonId;
                // get workTimeId
                var WorktimeId = input.workTimeId;
                //get strHourId
                string strHourId = await HandleService.GetListHourId(WorktimeId, SalonId);
                //convert workdate
                var WorkDate = Convert.ToDateTime(input.workDate, DatetimeExtension.GetCultureInfo());
                // convert strStaffId to list staffId
                var listStaffId = input.staffId.ConvertTimeKeeping();
                // add update SmEnrollTemp
                await HandleService.AddUpdateSMEnrollTemp(listStaffId, SalonId, WorkDate);
                // add update smEnrollTempHour
                await HandleService.AddUpdateSMEnrollTempHourListStaff(listStaffId, SalonId, WorkDate, strHourId);
                //
                return Ok(new { message = "Success", status = 1 });
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }
    }
}