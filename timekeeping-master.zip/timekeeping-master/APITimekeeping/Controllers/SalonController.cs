﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Repository.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace APITimekeeping.Controllers
{
    [Produces("application/json")]
    [Route("api/salon")]
    public class SalonController : Controller
    {
        private ILogger<SalonController> Logger { get; }
        private readonly IPushNotice PushNotice;
        private readonly ISalonRepo SalonRepo;
        //constructor
        public SalonController(ILogger<SalonController> logger,
            IPushNotice pushNotice,
            ISalonRepo salonRepo)
        {
            Logger = logger;
            PushNotice = pushNotice;
            SalonRepo = salonRepo;
        }

        /// <summary>
        /// Get salon 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int staffId)
        {
            try
            {
                if (staffId < 0)
                {
                    return BadRequest(new { message = "Mã nhân viên không hợp lệ!" });
                }
                //get
                var data = await SalonRepo.GetListSalon(staffId);
                //
                return Ok(data);
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }
    }
}