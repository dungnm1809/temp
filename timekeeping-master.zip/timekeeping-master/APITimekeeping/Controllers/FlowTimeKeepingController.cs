﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using APITimekeeping.Extentions;
using APITimekeeping.Models.CustomeModel;
using APITimekeeping.Models.Solution_30Shine;
using APITimekeeping.Repository.Interface;
using APITimekeeping.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using static APITimekeeping.Models.CustomeModel.OutPutModel;
using static APITimekeeping.Models.CustomeModel.InputModel;
using APITimekeeping.Service;

namespace APITimekeeping.Controllers
{
    [Produces("application/json")]
    [Route("api/flowtimeKeeping")]
    public class FlowTimeKeepingController : Controller
    {
        private ILogger<FlowTimeKeepingController> Logger { get; }
        private readonly IPushNotice PushNotice;
        private readonly IFlowTimeKeepingRepo FlowTimeKeepingRepo;
        private readonly IStaffRepo StaffRepo;
        private HandleService HandleService;
        //constructor
        public FlowTimeKeepingController(ILogger<FlowTimeKeepingController> logger,
            IPushNotice pushNotice,
            IFlowTimeKeepingRepo flowTimeKeepingRepo,
            IStaffRepo staffRepo,
            HandleService handleService)
        {
            Logger = logger;
            PushNotice = pushNotice;
            FlowTimeKeepingRepo = flowTimeKeepingRepo;
            StaffRepo = staffRepo;
            HandleService = handleService;
        }

        /// <summary>
        /// get timekeeping by staff
        /// </summary>
        /// <param name="staffId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetHourTimekeeping([FromQuery] int staffId, string workDate)
        {
            try
            {
                if (staffId <= 0)
                {
                    return BadRequest(new { message = "StaffId not exist!" });
                }
                OutPutModel.MainFlowTimeKeeping obj;
                obj = await HandleService.GetHourTimeKeeping(staffId, workDate);
                dynamic data = new ExpandoObject();
                data = obj;
                return Ok(data);
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", Inner: " + e.InnerException);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// Get ListStaff No Timekeeping
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        ///
        ///     {
        ///       "salonId": 2,
        ///       "departmentId": 1,
        ///       "workDate": "2018/10/25",
        ///     }
        ///
        /// </remarks>
        [HttpGet("get-list-staff-not-timekeeping")]
        public async Task<IActionResult> GetListStaffNoTimekeeping([FromQuery] int salonId, int departmentId, string workDate)
        {
            try
            {
                if (salonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (departmentId < 0)
                {
                    return BadRequest(new { message = "DepartmentId not exist!" });
                }
                if (string.IsNullOrEmpty(workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                var date = Convert.ToDateTime(workDate, DatetimeExtension.GetCultureInfo());
                // get list staff exist flowtimekeeping
                var listStaffTimekeeping = await FlowTimeKeepingRepo.GetList(r => r.SalonId == salonId
                                                                            && r.WorkDate == date
                                                                            && r.IsEnroll == true
                                                                            && r.IsDelete == 0);
                // get list staffId
                var listStaffIdTimekeeping = listStaffTimekeeping.Select(a => a.StaffId).ToList();
                //get data staff
                var data = await StaffRepo.GetListStaffNotTimekeeping(date, salonId, departmentId, listStaffIdTimekeeping);

                return Ok(data);
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// Get ListStaff  Timekeeping
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        ///
        ///     {
        ///       "salonId": 2,
        ///       "departmentId": 1,
        ///       "workDate": "2018/10/25",
        ///     }
        ///
        /// </remarks>
        [HttpGet("get-list-staff-timekeeping")]
        public async Task<IActionResult> GetListStaffTimekeeping([FromQuery] int salonId, int departmentId, string workDate)
        {
            try
            {
                if (salonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (departmentId < 0)
                {
                    return BadRequest(new { message = "DepartmentId not exist!" });
                }
                if (string.IsNullOrEmpty(workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                // convert datetime
                var date = Convert.ToDateTime(workDate, DatetimeExtension.GetCultureInfo());
                //get data
                var data = await FlowTimeKeepingRepo.GetListFlowTimekeeping(date, salonId, departmentId);
                if (data == null)
                {
                    return BadRequest(new { message = "Data does not exist!" });
                }

                return Ok(data);
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// add flowtimekeeping use erp
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "salonId": 2,
        ///         "staffId": "134,163,246,406,452,597,747,763,1021,1026",
        ///         "workDate": "2018/11/01",
        ///         "workTimeId":1,
        ///         "doUserId": 1113
        ///     }
        ///        
        /// </remarks>
        [HttpPost("insert-time-keeping")]
        public async Task<IActionResult> AddFlowtimekeeping([FromBody] InputAddEnroll input)
        {
            try
            {
                if (input.salonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (string.IsNullOrEmpty(input.staffId))
                {
                    return BadRequest(new { message = "StaffId not exist!" });
                }
                if (string.IsNullOrEmpty(input.workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                if (input.workTimeId <= 0)
                {
                    return BadRequest(new { message = "WorkTimeId not exist!" });
                }
                if (input.doUserId < 0)
                {
                    return BadRequest(new { message = "DoUserId not exist!" });
                }
                // get salon
                var SalonId = input.salonId;
                // get workTimeId
                var WorktimeId = input.workTimeId;
                // get doUserId
                var DoUserId = input.doUserId;
                //get strHourId
                string strHourId = await HandleService.GetListHourId(WorktimeId, SalonId);
                //convert workdate
                var WorkDate = Convert.ToDateTime(input.workDate, DatetimeExtension.GetCultureInfo());
                // convert strStaffId to list staffId
                var listStaffId = input.staffId.ConvertTimeKeeping();
                // add update flowtimekeeping
                await HandleService.AddUpdateFlowtimekeeping(SalonId, WorktimeId, WorkDate, listStaffId, DoUserId, strHourId);
                //
                return Ok(new { message = "Success", status = 1 });
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// Delete timkeeping use erp
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     {
        ///         "StaffId":163,
        ///         "SalonId":2,
        ///         "workDate":"14/12/2018"
        ///     }
        ///
        /// </remarks>
        [HttpDelete]
        public async Task<IActionResult> DeleteTimekeeping([FromBody] ReqDeleteTimekeeping param)
        {
            try
            {
                if (param == null)
                {
                    return BadRequest(new { message = "Data does not exist!" });
                }
                if (param.SalonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (param.StaffId <= 0)
                {
                    return BadRequest(new { message = "StaffId not exist!" });
                }
                if (string.IsNullOrEmpty(param.workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                // call
                await HandleService.DeleteTimekeeping(param.StaffId, param.SalonId, param.workDate);
                //
                return Ok(new { message = "Success", status = 1 });
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// add flowtimekeeping by app
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     {
        ///         "salonId": 2,
        ///         "staffId": "134,163,246,406,452,597,747,763,1021,1026",
        ///         "workDate": "2018/11/01",
        ///         "workTimeId":1,
        ///         "doUserId": 1113
        ///     }
        ///        
        /// </remarks>
        [HttpPost("insert-time-keeping-by-app")]
        public async Task<IActionResult> AddFlowtimekeepingByApp([FromBody] InputAddEnroll input)
        {
            try
            {
                if (input.salonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (string.IsNullOrEmpty(input.staffId))
                {
                    return BadRequest(new { message = "StaffId not exist!" });
                }
                if (string.IsNullOrEmpty(input.workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                if (input.workTimeId <= 0)
                {
                    return BadRequest(new { message = "WorkTimeId not exist!" });
                }
                if (input.doUserId < 0)
                {
                    return BadRequest(new { message = "DoUserId not exist!" });
                }
                //convert workdate
                var WorkDate = Convert.ToDateTime(input.workDate, DatetimeExtension.GetCultureInfo());
                if ((WorkDate.Date > DateTime.Now.Date) 
                    || (WorkDate.Date == DateTime.Now.Date 
                    && WorkDate <= DateTime.Now 
                    && DateTime.Now <= DateTime.Now.Date.AddDays(1).AddMinutes(-60)))
                {
                    // get salon
                    var SalonId = input.salonId;
                    // get workTimeId
                    var WorktimeId = input.workTimeId;
                    // get doUserId
                    var DoUserId = input.doUserId;
                    //get strHourId
                    string strHourId = await HandleService.GetListHourId(WorktimeId, SalonId);
                    // convert strStaffId to list staffId
                    var listStaffId = input.staffId.ConvertTimeKeeping();
                    // add update flowtimekeeping
                    await HandleService.AddUpdateFlowtimekeeping(SalonId, WorktimeId, WorkDate, listStaffId, DoUserId, strHourId);
                    // add salaryincome
                    await HandleService.InsertSalaryIncome(listStaffId, SalonId, WorkDate);
                    // add smenrolltemp
                    await HandleService.AddUpdateSMEnrollTemp(listStaffId, SalonId, WorkDate);
                    // add smenrolltemphour
                    await HandleService.AddUpdateSMEnrollTempHourListStaff(listStaffId, SalonId, WorkDate, strHourId);
                    // return
                    return Ok(new { message = "success", status = 1 });
                }
                else
                {
                    return BadRequest(new { message = "Đã quá giờ sửa chấm công!", status = 0 });
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }

        /// <summary>
        /// Delete timkeeping by app
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     {
        ///         "StaffId":"163",
        ///         "SalonId":2,
        ///         "workDate":"2018/12/04"
        ///     }
        ///
        /// </remarks>
        [HttpDelete("delete-time-keeping-by-app")]
        public async Task<IActionResult> DeleteTimkeepingByApp([FromBody] ReqDeleteTimekeepingByApp param)
        {
            try
            {
                if (param == null)
                {
                    return BadRequest(new { message = "Data does not exist!" });
                }
                if (param.SalonId <= 0)
                {
                    return BadRequest(new { message = "SalonId not exist!" });
                }
                if (string.IsNullOrEmpty(param.StaffId))
                {
                    return BadRequest(new { message = "StaffId not exist!" });
                }
                if (string.IsNullOrEmpty(param.workDate))
                {
                    return BadRequest(new { message = "WorkDate not exist!" });
                }
                //convert workdate
                var WorkDate = Convert.ToDateTime(param.workDate, DatetimeExtension.GetCultureInfo());
                if ((WorkDate.Date > DateTime.Now.Date) || (WorkDate.Date == DateTime.Now.Date && WorkDate <= DateTime.Now && DateTime.Now <= DateTime.Now.Date.AddDays(1).AddMinutes(-60)))
                {
                    //convert arr to list
                    var listStaffId = param.StaffId.ConvertTimeKeeping();
                    // call delete timkeeping
                    await HandleService.DeleteTimekeeping(Convert.ToInt32(param.StaffId), param.SalonId, param.workDate);
                    // call update salary when delete record timekeeping
                    await HandleService.InsertSalaryIncome(listStaffId, param.SalonId, WorkDate);
                    // return
                    return Ok(new { message = "success", status = 1 });
                }
                else
                {
                    return BadRequest(new { message = "Đã quá giờ hủy chấm công!", status = 0 });
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e.Message);
                PushNotice.PushErrorToSlack(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, e.Message + ", StackTrace: " + e.StackTrace);
                return StatusCode(500, new { message = e.Message });
            }
        }
    }
}
